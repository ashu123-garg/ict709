<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tech Org</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="./assets/icons/fontawesome/css/all.min.css">
</head>
<body class="login__screen">
    <div class="login__form left__part">
           <h1 class="logo__text"> Tech Org</h1>
           <form action="" method="post" class="mt-4 p-5 card login__form" onsubmit="return validateLoginForm()">
              <div class="alert alert-danger error__msg" style="display:none"></div>
                <div class="row"> 
                   <div class="col-md-12">
                       <div class="form-group">                          
                          <input type="email" name="email" id="email" class="form-control" autocomplete="off" placeholder="Email" required>
                       </div>
                       <div class="form-group">                          
                          <input type="password" name="password" id="password" class="form-control" autocomplete="off" placeholder="Password" required>
                       </div>
                       <div class="form-group">                          
                          <button type="submit" name="login_btn" class="btn bg__primary__color btn-block"> <i class="fa fa-check-circle"></i> Login</button>
                       </div>
                   </div>
                </div>
           </form>
    </div>
    <div class="login__img right__part"></div>
</body>
</html>

<!-- include jquery -->
<script src="./js/jquery.js"></script>
<script>
      function validateLoginForm(){
          let password = $("#password").val();
          let passwordPattern = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}$/;
          if(password.match(passwordPattern)){            
            $(".error__msg").hide();
            return true;
          }else{
            // fasle
            $(".error__msg").text("Password must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters");
            $(".error__msg").show();
            return false;
          }
      }
</script>

<?php
  if(
      isset($_POST["email"]) &&
      isset($_POST["password"]) &&
      isset($_POST["login_btn"]) 
){
    //TODO: step 1 check validation
    //TODO: step 2 check user exist or not in db
    // TODO if exist then redirect to dashboard and create session else show error

    if(
        !empty($_POST["email"]) &&
        !empty($_POST["password"]) 
        ){
          // proceed
          include "./backend/helper/ValidationHelper.php";
            $email = $_POST["email"];
            $password = $_POST["password"];
            $status= 'ACTIVE';

          if(!ValidationHelper::validateEmail($email)){
               //  if email validation failed
            ?>
            <script>
                $(".error__msg").text("Invalid Email");
                $(".error__msg").show();
            </script>
         <?php
          }elseif(!ValidationHelper::validatePassword($password)){
            //  if password validation failed
            ?>
               <script>
                   $(".error__msg").text("Password must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters");
                   $(".error__msg").show();
               </script>
            <?php
          }else{
            // check user authentication
            $password = md5($password);

            include "./backend/db.php";
            $sql =  $conn->prepare("SELECT USER_ID,USER_ROLE FROM users WHERE USER_EMAIL= ? AND USER_PASSWORD= ? AND USER_STATUS= ?");
            $sql->bind_param("ssi", $email, $password,$status);
            $sql->execute();
            $result = $sql->get_result();
            if($result->num_rows === 0){
              // unauthenticate user
            ?>
            <script>                    
                $(".error__msg").text("Sorry, invalid email AND password");
                $(".error__msg").css("display","block");
            </script>
         <?php
            }else{
              // authenticate user
              if($row= $result->fetch_assoc()){                     
                  $_SESSION["user_auth_id"] = $row["USER_ID"];  
                  $_SESSION["user_role"] = $row["USER_ROLE"];
                  header("Location:./user");                    
              }

              ?>
              <script>
                  $(".error__msg").hide();
              </script>
             <?php
            }
            $sql->close();
            $conn->close();
           
          }
        
          ?>
          <script>history.pushState({}, "", "")</script>
          <?php
        }
     
}
?>
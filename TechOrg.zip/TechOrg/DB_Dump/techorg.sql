-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 21, 2020 at 06:19 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `techorg`
--

-- --------------------------------------------------------

--
-- Table structure for table `additional_notes`
--

CREATE TABLE `additional_notes` (
  `ADDITIONAL_NOTES` int(11) NOT NULL,
  `STAFF_ID` int(11) NOT NULL,
  `NOTES` text NOT NULL,
  `RECORDED_BY` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `approvals`
--

CREATE TABLE `approvals` (
  `APPROVAL_ID` int(11) NOT NULL,
  `STAFF_ID` int(11) NOT NULL,
  `AQF_LEVEL_ID` int(11) NOT NULL,
  `APPROVED_AQF_LEVEL_ID` int(11) NOT NULL,
  `LOCATION_ID` int(11) NOT NULL,
  `IS_APPROVED` varchar(20) NOT NULL DEFAULT 'No',
  `APPROVE_DATE` date NOT NULL,
  `NEXT_REVIEW_DATE` date NOT NULL,
  `APPROVE_BY` int(11) NOT NULL,
  `APPROVAL_STATUS` varchar(30) NOT NULL DEFAULT 'Pending',
  `NOTES` text NOT NULL,
  `CREATED_AT` timestamp NOT NULL DEFAULT current_timestamp(),
  `UPDATED_AT` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `approvals`
--

INSERT INTO `approvals` (`APPROVAL_ID`, `STAFF_ID`, `AQF_LEVEL_ID`, `APPROVED_AQF_LEVEL_ID`, `LOCATION_ID`, `IS_APPROVED`, `APPROVE_DATE`, `NEXT_REVIEW_DATE`, `APPROVE_BY`, `APPROVAL_STATUS`, `NOTES`, `CREATED_AT`, `UPDATED_AT`) VALUES
(5, 22, 5, 0, 0, 'No', '0000-00-00', '0000-00-00', 0, 'Rejected', 'test', '2020-09-20 08:17:12', '2020-09-20 18:01:55'),
(6, 22, 2, 1, 4, 'Yes', '2020-09-20', '2020-09-21', 5, 'Approved', 'test', '2020-09-20 08:17:12', '2020-09-20 19:15:34');

-- --------------------------------------------------------

--
-- Table structure for table `aqflevels`
--

CREATE TABLE `aqflevels` (
  `AQF_LEVEL_ID` int(10) NOT NULL,
  `QUALIFIED_DEGREE` varchar(255) NOT NULL,
  `AQF_LEVEL` int(11) NOT NULL,
  `QUALIFICATION_LEVEL_REQUIRED_TO_TEACH` varchar(20) NOT NULL,
  `AQF_STATUS` varchar(20) NOT NULL DEFAULT 'Active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `aqflevels`
--

INSERT INTO `aqflevels` (`AQF_LEVEL_ID`, `QUALIFIED_DEGREE`, `AQF_LEVEL`, `QUALIFICATION_LEVEL_REQUIRED_TO_TEACH`, `AQF_STATUS`) VALUES
(1, 'Bachelor degree', 7, '8', 'Active'),
(2, 'Bachelor Honours degree', 8, '9', 'Active'),
(3, 'Graduate Certificate', 8, '9', 'Active'),
(4, 'Graduate Diploma', 8, '9', 'Active'),
(5, 'Masters', 9, '10', 'Active'),
(6, 'PhD', 10, '10', 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `document`
--

CREATE TABLE `document` (
  `DOCUMENT_ID` int(11) NOT NULL,
  `STAFF_ID` int(11) NOT NULL,
  `DOCS_NAME` varchar(256) NOT NULL,
  `CREATE_BY` int(11) NOT NULL,
  `DOCUMENT_CREATE_AT` timestamp NOT NULL DEFAULT current_timestamp(),
  `DOCUMENT_UPDATE_AT` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `document`
--

INSERT INTO `document` (`DOCUMENT_ID`, `STAFF_ID`, `DOCS_NAME`, `CREATE_BY`, `DOCUMENT_CREATE_AT`, `DOCUMENT_UPDATE_AT`) VALUES
(5, 22, 'Resume', 4, '2020-09-20 08:17:12', '2020-09-20 12:22:16'),
(6, 22, 'Degree', 4, '2020-09-20 08:17:12', '2020-09-20 12:22:20');

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE `location` (
  `LOCATION_ID` int(10) NOT NULL,
  `BUILDING_NAME` varchar(128) DEFAULT NULL,
  `STREET_NAME` varchar(128) DEFAULT NULL,
  `CITY` varchar(128) DEFAULT NULL,
  `STATE` varchar(128) DEFAULT NULL,
  `ZIP_CODE` int(10) DEFAULT NULL,
  `COUNTRY` varchar(128) DEFAULT NULL,
  `STATUS` varchar(20) NOT NULL DEFAULT 'Active',
  `CREATE_AT` timestamp NOT NULL DEFAULT current_timestamp(),
  `UPDATE_AT` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `UPDATE_BY` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`LOCATION_ID`, `BUILDING_NAME`, `STREET_NAME`, `CITY`, `STATE`, `ZIP_CODE`, `COUNTRY`, `STATUS`, `CREATE_AT`, `UPDATE_AT`, `UPDATE_BY`) VALUES
(1, 'SS NILAYAM', 'ANAND Street', 'AMARAVATHI', 'ANDHRAPRADESH', 522020, 'INDIA', 'Active', '2020-09-18 08:57:29', '2020-09-18 08:57:29', 0),
(2, 'INCOR HEIGHTS', 'EAT Street', 'GUNTUR', 'ANDHRAPRADESH', 522012, 'INDIA', 'Active', '2020-09-18 08:57:29', '2020-09-18 08:57:29', 0),
(3, 'LODHA HEIGHTS', 'State Street', 'VIJAYAWADA', 'ANDHRAPRADESH', 522123, 'INDIA', 'Active', '2020-09-18 08:57:29', '2020-09-18 08:57:29', 0),
(4, 'CITY CENTER', '2 Boonah Qld', 'CLARENDON', 'Queensland', 4311, 'AUS', 'Active', '2020-09-18 08:57:29', '2020-09-18 08:57:29', 0),
(5, 'FORUM CENTER', '26  Bathurst Road', 'PERTHVILLE', 'New South Wales', 2795, 'AUSTRALIA', 'Active', '2020-09-18 08:57:29', '2020-09-18 08:57:29', 0),
(6, 'SD Buildings', 'TT Road', 'Hyderabad', 'TELANGANA', 56789, 'INDIA', 'Active', '2020-09-18 08:57:29', '2020-09-18 08:57:29', 0),
(7, 'LODHA Heights', 'RTO ROAD', 'Hyderabad', 'TELANGANA', 56889, 'INDIA', 'Active', '2020-09-18 08:57:29', '2020-09-18 08:57:29', 0),
(8, 'INCOR Heights', 'HITEX ROAD', 'Hyderabad', 'TELANGANA', 56999, 'INDIA', 'Active', '2020-09-18 08:57:29', '2020-09-18 08:57:29', 0),
(9, 'VBIT PARK', 'INORBIT MALL ROAD', 'Hyderabad', 'TELANGANA', 54321, 'INDIA', 'Active', '2020-09-18 08:57:29', '2020-09-18 08:57:29', 0),
(10, 'MIND SPACE', 'Hitech City Road', 'Hyderabad', 'TELANGANA', 54893, 'INDIA', 'Active', '2020-09-18 08:57:29', '2020-09-18 08:57:29', 0);

-- --------------------------------------------------------

--
-- Table structure for table `other_relevant_information`
--

CREATE TABLE `other_relevant_information` (
  `REL_INFO_ID` int(11) NOT NULL,
  `STAFF_ID` int(11) NOT NULL,
  `RELEVANT_INFO` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `other_relevant_information`
--

INSERT INTO `other_relevant_information` (`REL_INFO_ID`, `STAFF_ID`, `RELEVANT_INFO`) VALUES
(3, 22, 'Member of Australian Computer Society, Local school board member');

-- --------------------------------------------------------

--
-- Table structure for table `publications`
--

CREATE TABLE `publications` (
  `PUBLICATION_ID` int(10) NOT NULL,
  `STAFF_ID` int(10) NOT NULL,
  `AUTHOR_SURNAME` varchar(200) NOT NULL,
  `AUTHOR_INITIAL` varchar(100) NOT NULL,
  `YEAR_OF_PUBLICATION` int(10) NOT NULL,
  `TITLE_OF_PUBLICATION` varchar(128) NOT NULL,
  `TYPE_OF_PUBLICATION` varchar(128) NOT NULL,
  `PEER_REVIEWED` varchar(5) NOT NULL,
  `CLASSIFICATION` varchar(50) NOT NULL,
  `BROAD_FIELD_EDUCATION` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `publications`
--

INSERT INTO `publications` (`PUBLICATION_ID`, `STAFF_ID`, `AUTHOR_SURNAME`, `AUTHOR_INITIAL`, `YEAR_OF_PUBLICATION`, `TITLE_OF_PUBLICATION`, `TYPE_OF_PUBLICATION`, `PEER_REVIEWED`, `CLASSIFICATION`, `BROAD_FIELD_EDUCATION`) VALUES
(11, 22, 'Smith', 'J', 2015, 'The role of ICT in university teaching', 'Journal', 'Yes', 'Research', 'ICT'),
(12, 22, 'Smith', 'J', 2012, 'ICT in schools', 'Book Chapters', 'No', 'Scholarship', 'ICT');

-- --------------------------------------------------------

--
-- Table structure for table `qualification`
--

CREATE TABLE `qualification` (
  `QUALIFICATION_ID` int(11) NOT NULL,
  `STAFF_ID` int(10) NOT NULL,
  `AQF_LEVEL_ID` int(10) NOT NULL,
  `SUBJECT_AREA` varchar(255) NOT NULL,
  `INSTITUTION_NAME` varchar(255) NOT NULL,
  `INSTITUTION_COUNTRY` varchar(255) NOT NULL,
  `FULL_NAME_OF_AWARD` varchar(255) DEFAULT NULL,
  `AWARDED_YEAR` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `qualification`
--

INSERT INTO `qualification` (`QUALIFICATION_ID`, `STAFF_ID`, `AQF_LEVEL_ID`, `SUBJECT_AREA`, `INSTITUTION_NAME`, `INSTITUTION_COUNTRY`, `FULL_NAME_OF_AWARD`, `AWARDED_YEAR`) VALUES
(17, 22, 5, 'Database Programming', 'University of the Sunshine Coast', 'Australia', 'Masters of IT', '2020-09'),
(18, 22, 2, 'ICT', 'University of Tasmania', 'Australia', 'Bachelors Honours ', '2019-07');

-- --------------------------------------------------------

--
-- Table structure for table `relevant_employment_experience`
--

CREATE TABLE `relevant_employment_experience` (
  `RELEVANT_EXPERIENCE_ID` int(11) NOT NULL,
  `STAFF_ID` int(10) NOT NULL,
  `JOINING_DATE` date NOT NULL,
  `FINISH_DATE` date NOT NULL,
  `EMPLOYMENT_TYPE` varchar(50) NOT NULL,
  `EMPLOYER_NAME` varchar(256) NOT NULL,
  `POSITION_TITLE` varchar(256) NOT NULL,
  `RELEVANT_DUTIES` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `relevant_teaching_experience`
--

CREATE TABLE `relevant_teaching_experience` (
  `TEACHING_EXPERIENCE_ID` int(11) NOT NULL,
  `STAFF_ID` int(10) NOT NULL,
  `JOINING_DATE` date NOT NULL,
  `FINISH_DATE` date NOT NULL,
  `INSTITUTION_NAME` varchar(256) NOT NULL,
  `INSTITUTION_COUNTRY` varchar(200) NOT NULL,
  `ROLE` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `relevant_teaching_experience`
--

INSERT INTO `relevant_teaching_experience` (`TEACHING_EXPERIENCE_ID`, `STAFF_ID`, `JOINING_DATE`, `FINISH_DATE`, `INSTITUTION_NAME`, `INSTITUTION_COUNTRY`, `ROLE`) VALUES
(12, 22, '2017-07-20', '2020-09-20', 'Victoria University', 'Australia', 'Lecturer'),
(13, 22, '2016-02-20', '2017-07-19', 'USQ', 'Australia', 'Tutor');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `REVIEW_ID` int(10) NOT NULL,
  `STAFF_ID` int(10) NOT NULL,
  `ADMIN_ID` int(10) NOT NULL,
  `REVIEW_DATE` date NOT NULL,
  `OUTCOME` varchar(50) NOT NULL,
  `NOTES` text NOT NULL,
  `CREATE_AT` timestamp NOT NULL DEFAULT current_timestamp(),
  `UPDATE_AT` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`REVIEW_ID`, `STAFF_ID`, `ADMIN_ID`, `REVIEW_DATE`, `OUTCOME`, `NOTES`, `CREATE_AT`, `UPDATE_AT`) VALUES
(1, 22, 2, '2018-08-15', 'Continue', '', '2020-09-20 06:53:31', '2020-09-21 03:31:14'),
(2, 1, 2, '2018-10-01', 'Warning', '', '2020-09-20 06:53:31', '2020-09-20 06:53:31'),
(3, 2, 1, '2018-01-01', 'TERMINATE', '', '2020-09-20 06:53:31', '2020-09-20 06:53:31'),
(4, 22, 5, '2020-09-21', 'Warning', 'testing', '2020-09-21 04:15:18', '2020-09-21 04:15:18');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `STAFF_ID` int(10) NOT NULL,
  `TITLE` varchar(5) NOT NULL,
  `FIRST_NAME` varchar(128) NOT NULL,
  `LAST_NAME` varchar(128) NOT NULL,
  `EMAIL` varchar(128) NOT NULL,
  `PHONE_NO` decimal(12,0) NOT NULL,
  `STAFF_ADDRESS` text NOT NULL,
  `TEACHING_EXPERIENCE` varchar(20) NOT NULL DEFAULT 'No',
  `RELEVENT_EMPLOYMENT_EXPERIENCE` varchar(20) NOT NULL DEFAULT 'No',
  `PUBLICATION` varchar(20) NOT NULL DEFAULT 'No',
  `STAFF_STATUS` varchar(20) NOT NULL DEFAULT 'Active',
  `STAFF_CREATE_AT` timestamp NOT NULL DEFAULT current_timestamp(),
  `STAFF_UPDATE_AT` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`STAFF_ID`, `TITLE`, `FIRST_NAME`, `LAST_NAME`, `EMAIL`, `PHONE_NO`, `STAFF_ADDRESS`, `TEACHING_EXPERIENCE`, `RELEVENT_EMPLOYMENT_EXPERIENCE`, `PUBLICATION`, `STAFF_STATUS`, `STAFF_CREATE_AT`, `STAFF_UPDATE_AT`) VALUES
(22, 'Mr', 'Jonathan', 'Smith', 'jsmith@gmail.com', '4100100100', '1 Main Street, Brisbane, QLD 4000', 'Yes', 'No', 'Yes', 'Active', '2020-09-20 08:17:12', '2020-09-20 08:17:12');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `USER_ID` int(11) NOT NULL,
  `USER_FIRST_NAME` varchar(100) NOT NULL,
  `USER_LAST_NAME` varchar(100) NOT NULL,
  `USER_EMAIL` varchar(100) NOT NULL,
  `USER_PASSWORD` varchar(100) NOT NULL,
  `USER_ROLE` int(11) NOT NULL DEFAULT 0,
  `USER_STATUS` varchar(20) NOT NULL DEFAULT 'ACTIVE',
  `USER_CREATE_AT` timestamp NOT NULL DEFAULT current_timestamp(),
  `USER_UPDATE_AT` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `USER_UPDATE_BY` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`USER_ID`, `USER_FIRST_NAME`, `USER_LAST_NAME`, `USER_EMAIL`, `USER_PASSWORD`, `USER_ROLE`, `USER_STATUS`, `USER_CREATE_AT`, `USER_UPDATE_AT`, `USER_UPDATE_BY`) VALUES
(4, 'Karan', 'Soni', 'test123@gmail.com', '5facbc1aedb69afddcd65a765116f527', 0, 'ACTIVE', '2020-09-20 08:39:47', '2020-09-21 04:18:33', 0),
(5, 'Karan', 'Soni', 'test12345@gmail.com', '5facbc1aedb69afddcd65a765116f527', 1, 'ACTIVE', '2020-09-20 08:39:47', '2020-09-21 04:18:43', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `additional_notes`
--
ALTER TABLE `additional_notes`
  ADD PRIMARY KEY (`ADDITIONAL_NOTES`);

--
-- Indexes for table `approvals`
--
ALTER TABLE `approvals`
  ADD PRIMARY KEY (`APPROVAL_ID`);

--
-- Indexes for table `aqflevels`
--
ALTER TABLE `aqflevels`
  ADD PRIMARY KEY (`AQF_LEVEL_ID`);

--
-- Indexes for table `document`
--
ALTER TABLE `document`
  ADD PRIMARY KEY (`DOCUMENT_ID`);

--
-- Indexes for table `location`
--
ALTER TABLE `location`
  ADD PRIMARY KEY (`LOCATION_ID`);

--
-- Indexes for table `other_relevant_information`
--
ALTER TABLE `other_relevant_information`
  ADD PRIMARY KEY (`REL_INFO_ID`);

--
-- Indexes for table `publications`
--
ALTER TABLE `publications`
  ADD PRIMARY KEY (`PUBLICATION_ID`);

--
-- Indexes for table `qualification`
--
ALTER TABLE `qualification`
  ADD PRIMARY KEY (`QUALIFICATION_ID`),
  ADD KEY `FKQualificat68980` (`AQF_LEVEL_ID`);

--
-- Indexes for table `relevant_employment_experience`
--
ALTER TABLE `relevant_employment_experience`
  ADD PRIMARY KEY (`RELEVANT_EXPERIENCE_ID`);

--
-- Indexes for table `relevant_teaching_experience`
--
ALTER TABLE `relevant_teaching_experience`
  ADD PRIMARY KEY (`TEACHING_EXPERIENCE_ID`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`REVIEW_ID`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`STAFF_ID`),
  ADD UNIQUE KEY `EmailId` (`EMAIL`),
  ADD UNIQUE KEY `PhoneNo` (`PHONE_NO`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`USER_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `additional_notes`
--
ALTER TABLE `additional_notes`
  MODIFY `ADDITIONAL_NOTES` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `approvals`
--
ALTER TABLE `approvals`
  MODIFY `APPROVAL_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `aqflevels`
--
ALTER TABLE `aqflevels`
  MODIFY `AQF_LEVEL_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `document`
--
ALTER TABLE `document`
  MODIFY `DOCUMENT_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `location`
--
ALTER TABLE `location`
  MODIFY `LOCATION_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `other_relevant_information`
--
ALTER TABLE `other_relevant_information`
  MODIFY `REL_INFO_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `publications`
--
ALTER TABLE `publications`
  MODIFY `PUBLICATION_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `qualification`
--
ALTER TABLE `qualification`
  MODIFY `QUALIFICATION_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `relevant_employment_experience`
--
ALTER TABLE `relevant_employment_experience`
  MODIFY `RELEVANT_EXPERIENCE_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `relevant_teaching_experience`
--
ALTER TABLE `relevant_teaching_experience`
  MODIFY `TEACHING_EXPERIENCE_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `REVIEW_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `STAFF_ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `USER_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `qualification`
--
ALTER TABLE `qualification`
  ADD CONSTRAINT `FKQualificat68980` FOREIGN KEY (`AQF_LEVEL_ID`) REFERENCES `aqflevels` (`AQF_LEVEL_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

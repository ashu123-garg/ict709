function openNav() {
  document.getElementById("mySidebar").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
  document.getElementById("openBtn").style.display = "none";
  document.getElementById("pageHeadingOpenSidebar").style.display = "block";
  document.getElementById("pageHeadingCloseSidebar").style.display = "none";
}

function closeNav() {
  document.getElementById("mySidebar").style.width = "0";
  document.getElementById("main").style.marginLeft = "0";
  document.getElementById("openBtn").style.display = "block";
  document.getElementById("pageHeadingOpenSidebar").style.display = "none";
  document.getElementById("pageHeadingCloseSidebar").style.display = "block";
}

<?php 
  class Approvals{
     // conn
    private $conn;

    // constructor
    public function __construct($conn){        
        $this->conn = $conn;
    }


     //* [rejectApprovalRequest]
     public function rejectApprovalRequest($APPROVAL_ID,$REJECT_NOTE){
        $userId = $_SESSION["user_auth_id"];
      $sql="UPDATE approvals SET IS_APPROVED='No', APPROVAL_STATUS='Rejected',NOTES='$REJECT_NOTE' WHERE APPROVAL_ID='$APPROVAL_ID'";
      return $this->conn->query($sql);      
    }

     //* [getAllActiveAqfLevels]
    public function getAllActiveAqfLevels(){
        $sql="SELECT * FROM  aqflevels WHERE  AQF_STATUS='Active' ORDER BY QUALIFIED_DEGREE ASC";
        $result = $this->conn->query($sql);
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        return $rows;
    }

    //* [getAllActiveAqfLevels]
    public function getAllActiveLocations(){
        $sql="SELECT LOCATION_ID,BUILDING_NAME FROM  location WHERE  STATUS='Active' ORDER BY BUILDING_NAME ASC";
        $result = $this->conn->query($sql);
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        return $rows;
    }

     //* [approvedApprovalRequest]
     public function approvedApprovalRequest($APPROVAL_ID,$LOCATION_ID,$APPROVED_AQF_LEVEL_ID,$NEXT_REVIEW_DATE,$APPROVE_NOTE){
        $userId = $_SESSION["user_auth_id"];
        $date = date('Y-m-d');
      $sql="UPDATE approvals SET IS_APPROVED='Yes',LOCATION_ID='$LOCATION_ID',APPROVED_AQF_LEVEL_ID='$APPROVED_AQF_LEVEL_ID',NEXT_REVIEW_DATE='$NEXT_REVIEW_DATE', APPROVAL_STATUS='Approved',NOTES='$APPROVE_NOTE',APPROVE_BY='$userId',APPROVE_DATE='$date' WHERE APPROVAL_ID='$APPROVAL_ID'";
      return $this->conn->query($sql);      
    }

    // **getAllPendingApprovals
    public function getAllPendingApprovals(){
        $sql="SELECT approvals.*, aqflevels.QUALIFIED_DEGREE,staff.TITLE,staff.FIRST_NAME,staff.LAST_NAME,staff.EMAIL,staff.PHONE_NO,staff.STAFF_ADDRESS FROM approvals  left join staff on approvals.STAFF_ID=staff.STAFF_ID left join aqflevels on approvals.AQF_LEVEL_ID=aqflevels.AQF_LEVEL_ID  ORDER BY approvals.APPROVAL_ID DESC";
        // WHERE approvals.IS_APPROVED='No'
        $result = $this->conn->query($sql);
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        return $rows;
    }

    public function getApprovalsDetailsById($approvalId){
        $sql="SELECT approvals.*, aqflevels.QUALIFIED_DEGREE,aqflevels.AQF_LEVEL,aqflevels.QUALIFICATION_LEVEL_REQUIRED_TO_TEACH,staff.TITLE,staff.FIRST_NAME,staff.LAST_NAME,staff.EMAIL,staff.PHONE_NO,staff.STAFF_ADDRESS FROM approvals  left join staff on approvals.STAFF_ID=staff.STAFF_ID left join aqflevels on approvals.AQF_LEVEL_ID=aqflevels.AQF_LEVEL_ID  WHERE approvals.APPROVAL_ID='$approvalId'";
        $result = $this->conn->query($sql);
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        return $rows;
    }

    public function getApprovalsDetailsByStaffId($staffId){
        $sql="SELECT approvals.*, aqflevels.QUALIFIED_DEGREE,aqflevels.AQF_LEVEL,aqflevels.QUALIFICATION_LEVEL_REQUIRED_TO_TEACH,staff.TITLE,staff.FIRST_NAME,staff.LAST_NAME,staff.EMAIL,staff.PHONE_NO,staff.STAFF_ADDRESS FROM approvals  left join staff on approvals.STAFF_ID=staff.STAFF_ID left join aqflevels on approvals.AQF_LEVEL_ID=aqflevels.AQF_LEVEL_ID WHERE approvals.STAFF_ID='$staffId'";
        $result = $this->conn->query($sql);
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        return $rows;
    }

    public function getQualificationDetailsByStaffId($staffId){
        $sql="SELECT  qualification.*, aqflevels.QUALIFIED_DEGREE,aqflevels.AQF_LEVEL,aqflevels.QUALIFICATION_LEVEL_REQUIRED_TO_TEACH FROM qualification left join aqflevels on qualification.AQF_LEVEL_ID=aqflevels.AQF_LEVEL_ID WHERE qualification.STAFF_ID='$staffId' ";
        $result = $this->conn->query($sql);
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        return $rows;
    }

    public function getPersonalDetailsByStaffId($staffId){
        $sql="SELECT  *  from staff WHERE staff.STAFF_ID='$staffId' ";
        $result = $this->conn->query($sql);
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        return $rows;
    }

    public function getTeachingExperienceByStaffId($staffId){
        $sql="SELECT  relevant_teaching_experience.* FROM relevant_teaching_experience  WHERE relevant_teaching_experience.STAFF_ID='$staffId' ";
        $result = $this->conn->query($sql);
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        return $rows;
    }

    public function getRelevantEmployementExperienceByStaffId($staffId){
        $sql="SELECT  relevant_employment_experience.* FROM relevant_employment_experience  WHERE relevant_employment_experience.STAFF_ID='$staffId' ";
        $result = $this->conn->query($sql);
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        return $rows;
    }

    public function getOtherRelevantInfoByStaffId($staffId){
        $sql="SELECT  other_relevant_information.* FROM other_relevant_information  WHERE other_relevant_information.STAFF_ID='$staffId' ";
        $result = $this->conn->query($sql);
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        return $rows;
    }

    public function getPublicationDetailsByStaffId($staffId){
        $sql="SELECT  publications.* FROM publications  WHERE publications.STAFF_ID='$staffId' ";
        $result = $this->conn->query($sql);
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        return $rows;
    }

    public function getDocumentDetailsByStaffId($staffId){
        $sql="SELECT  document.*,users.USER_FIRST_NAME FROM document  left join users on document.CREATE_BY= users.USER_ID  WHERE document.STAFF_ID='$staffId'";
        $result = $this->conn->query($sql);
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        return $rows;
    }


    public function getLocationDetailsById($locationId){
        $sql="SELECT  location.* from location WHERE location.LOCATION_ID='$locationId'";
        $result = $this->conn->query($sql);
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        return $rows;
    }

    public function getApprovedAqfLevelById($aqfLeveId){    
        $sql="SELECT  aqflevels.* from aqflevels WHERE aqflevels.AQF_LEVEL_ID='$aqfLeveId'";
        $result = $this->conn->query($sql);
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        return $rows;
    }

    // **[getAllUserCount] 
    public function getAllNewApprovalRequest(){
      $sql="SELECT count(*) as total FROM approvals WHERE IS_APPROVED='No'";
      $result = $this->conn->query($sql);
      $rows = $result->fetch_all(MYSQLI_ASSOC);
      $this->conn -> close();
      return $rows[0]["total"];
    }

    
  }
?>
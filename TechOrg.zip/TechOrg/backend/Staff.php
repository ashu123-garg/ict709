<?php 
class Staff{
    // conn
    private $conn;

    // constructor
    public function __construct($conn){        
        $this->conn = $conn;
    }
     

    // **get list of all active Staff Members
    public function getActiveStaffMembers(){
        $sql="SELECT * FROM  staff WHERE  STAFF_STATUS='Active' ORDER BY 	FIRST_NAME ASC";
        $result = $this->conn->query($sql);
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        $this->conn -> close();
        return $rows;
    }


    
    // **get list of all in-active Staff Members
    public function getInActiveReminders(){
        $sql="SELECT * FROM  staff WHERE  STAFF_STATUS='InActive' ORDER BY 	FIRST_NAME ASC";
        $result = $this->conn->query($sql);
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        $this->conn -> close();
        return $rows;
    }


    // **getStaffFromId
    public function getStaffFromId($staffId){
        $sql="SELECT * FROM staff WHERE STAFF_ID='$staffId'";
        $result = $this->conn->query($sql);
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        return $rows;
    }

    // **getStaffFromId
    public function getAllStaffCount($status ='Active'){
        $sql="SELECT count(*) as total FROM staff WHERE STAFF_STATUS='$status'";
        $result = $this->conn->query($sql);
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        $this->conn -> close();
        return $rows[0]["total"];
    }

    // **insertNewStaffMember
    public function insertNewStaffMember($title,$firstName,$lastName,$email,$phone,$address,$teachingExperience,$releventEploymentExperience,$publication){
        $selectQuery = "SELECT COUNT(*) AS total FROM staff WHERE EMAIL='$email' OR PHONE_NO='$phone'";
        $selectResult = $this->conn->query($selectQuery);
        if($row = $selectResult->fetch_assoc()){
           if($row['total'] == 1){
                 return -1;
           } 
        }
        $sql="INSERT INTO staff(TITLE,FIRST_NAME,LAST_NAME,EMAIL,PHONE_NO,STAFF_ADDRESS,TEACHING_EXPERIENCE,RELEVENT_EMPLOYMENT_EXPERIENCE,PUBLICATION)VALUES('$title','$firstName','$lastName','$email','$phone','$address','$teachingExperience','$releventEploymentExperience','$publication')";         
         if($this->conn->query($sql)){
             $staffId =  $this->conn->insert_id;
             return $staffId;
         }else{
             return false;
         }
    }

    // **insertStaffQualification
    public function insertStaffQualification($staffId,$aqfLevel,$subjectArea,$institutionName,$country,$fullNameOfAward,$awardYear){
        $itemLength = count($aqfLevel);
        for($index=0;$index<$itemLength; $index++){
            $sql="INSERT INTO qualification(STAFF_ID,AQF_LEVEL_ID,SUBJECT_AREA,INSTITUTION_NAME,INSTITUTION_COUNTRY,FULL_NAME_OF_AWARD,	AWARDED_YEAR)VALUES('$staffId','$aqfLevel[$index]','$subjectArea[$index]','$institutionName[$index]','$country[$index]','$fullNameOfAward[$index]','$awardYear[$index]')";  
            
             $approvalSql="INSERT INTO approvals(STAFF_ID,AQF_LEVEL_ID)VALUES('$staffId','$aqfLevel[$index]')";

            $this->conn->query($sql);               
            $this->conn->query($approvalSql);               
        }  
        return true;
    }

     // **insertTeachingExperience
     public function insertTeachingExperience($staffId,$joiningDate,$finishDate,$institutionName,$country,$role){
        $itemLength = count($joiningDate);
        for($index=0;$index<$itemLength; $index++){
            $sql="INSERT INTO relevant_teaching_experience(STAFF_ID,JOINING_DATE,FINISH_DATE,INSTITUTION_NAME,INSTITUTION_COUNTRY,ROLE)VALUES('$staffId','$joiningDate[$index]','$finishDate[$index]','$institutionName[$index]','$country[$index]','$role[$index]')";         
            $this->conn->query($sql);               
        }  
        return true;
    }


      // **insertPublication
      public function insertPublication($staffId,$authorSurname,$authorInitial,$publicationYear,$publicationTitle,$publicationType,$peerReviewd,$publicationClassification,$broadFieldEducation){
        $itemLength = count($authorSurname);
        for($index=0;$index<$itemLength; $index++){
            $sql="INSERT INTO  publications(STAFF_ID,AUTHOR_SURNAME,AUTHOR_INITIAL,YEAR_OF_PUBLICATION,TITLE_OF_PUBLICATION,TYPE_OF_PUBLICATION,PEER_REVIEWED,CLASSIFICATION,BROAD_FIELD_EDUCATION)VALUES('$staffId','$authorSurname[$index]','$authorInitial[$index]','$publicationYear[$index]','$publicationTitle[$index]','$publicationType[$index]','$peerReviewd[$index]','$publicationClassification[$index]','$broadFieldEducation[$index]')";         
            $this->conn->query($sql);               
        }  
        return true;
    }
    
     // **insertRelevantEmploymentExperience
     public function insertRelevantEmploymentExperience($staffId,$joiningDate,$finishDate,$employmentType,$employerName,$positionTitle,$relevantDuties){
        $itemLength = count($joiningDate);
        for($index=0;$index<$itemLength; $index++){
            $sql="INSERT INTO relevant_teaching_experience(STAFF_ID,JOINING_DATE,FINISH_DATE,EMPLOYMENT_TYPE,EMPLOYER_NAME,	POSITION_TITLE,RELEVANT_DUTIES)VALUES('$staffId','$joiningDate[$index]','$finishDate[$index]','$employmentType[$index]','$employerName[$index]','$positionTitle[$index]','$relevantDuties[$index]')";         
            $this->conn->query($sql);               
        }  
        return true;
    }

    // **insertOtherRelevantInfo
    public function insertOtherRelevantInfo($staffId,$relevantInfo){
       $sql="INSERT INTO  other_relevant_information(STAFF_ID,RELEVANT_INFO)VALUES('$staffId','$relevantInfo')";         
            $this->conn->query($sql);               
        return true;
    }

    // **insertDocuments
    public function insertDocuments($staffId,$document){
        $userId = $_SESSION["user_auth_id"];
        $itemLength = count($document);
         for($index=0;$index<$itemLength; $index++){
            $sql="INSERT INTO  document(STAFF_ID,DOCS_NAME,CREATE_BY)VALUES('$staffId','$document[$index]','$userId')";         
            $this->conn->query($sql);       
         }        
         return true;
     }


    // **setInactiveReminder
    public function setInactiveStaffMember($staffId){
        $sql="UPDATE staff SET STAFF_STATUS='InActive' WHERE STAFF_ID='$staffId'";
        return $this->conn->query($sql);
    }

       // **deleteStaffMember
       public function deleteStaffMember($staffId){
        $sql="DELETE FROM staff WHERE STAFF_ID='$staffId'";
        return $this->conn->query($sql);
    }

    // **setActiveStaffMember
    public function setActiveStaffMember($staffId){
        $sql="UPDATE staff SET STAFF_STATUS='1' WHERE STAFF_ID='$staffId'";
        return $this->conn->query($sql);
    }

    // **updateStaff
    public function updateStaff($staffId,$title,$firstName,$lastName,$email,$phone,$teachingExperience,$releventEploymentExperience,$publication){
        $userId = $_SESSION["user_auth_id"];
        $sql="UPDATE staff SET TITLE ='$title',FIRST_NAME='$firstName',LAST_NAME='$lastName',EMAIL='$email',PHONE_NO='$phone',TEACHING_EXPERIENCE='$teachingExperience',RELEVENT_EMPLOYMENT_EXPERIENCE='$releventEploymentExperience',PUBLICATION ='$publication',STAFF_UPDATE_BY ='$userId'
        WHERE STAFF_ID='$staffId'";
        return $this->conn->query($sql);
    }


}
?>
<?php 
  class User{
     // conn
    private $conn;

    // constructor
    public function __construct($conn){        
        $this->conn = $conn;
    }


     //* [insertNewUser] it will insert new user into DB
     public function insertNewUser($userFirstName,$userLastName,$userEmail,$userEncryptedPassword,$userRole){
       $select_query = "SELECT COUNT(*) as total  FROM users WHERE USER_EMAIL='$userEmail'";
       $select_query_result =  $this->conn->query($select_query); 
       if($row = $select_query_result->fetch_assoc()){
        if($row['total'] > 0){
          return -1;
        } 
       }
      $userId = $_SESSION["user_auth_id"];
      $sql="INSERT INTO users(USER_FIRST_NAME,USER_LAST_NAME,USER_EMAIL,USER_PASSWORD,USER_ROLE,USER_UPDATE_BY)VALUES('$userFirstName','$userLastName','$userEmail','$userEncryptedPassword','$userRole','$userId')";
      return $this->conn->query($sql);      
    }


    //* [getUserFirstName] it will give us current user first name
    public function getUserFirstName(){
      $userId = $_SESSION["user_auth_id"];
      $sql="SELECT USER_FIRST_NAME from users WHERE USER_ID='$userId'";
      $result = $this->conn->query($sql);
      if($row=$result->fetch_assoc()){
          return $row["USER_FIRST_NAME"];
      }
    }

    //* [getUserDetails] it will give us current user details
    public function getUserDetails(){
      $userId = $_SESSION["user_auth_id"];
      $sql="SELECT * from users WHERE USER_ID='$userId'";
      $result = $this->conn->query($sql);
      if($row=$result->fetch_assoc()){
          return $row;
      }else{
        return [];
      }
    }
     
     //* [getUserLastName] it will give us current user last name
     public function getUserLastName(){
      $userId = $_SESSION["user_auth_id"];
      $sql="SELECT USER_LAST_NAME from users WHERE USER_ID='$userId'";
      $result = $this->conn->query($sql);
      if($row=$result->fetch_assoc()){
          return $row["USER_LAST_NAME"];
      }
    }

     //* [getUserFullName] it will give us current user full name
     public function getUserFullName(){
       $userId = $_SESSION["user_auth_id"];
      $sql="SELECT concat(USER_FIRST_NAME,USER_LAST_NAME) as fullName from users WHERE USER_ID='$userId'";
      $result = $this->conn->query($sql);
      if($row=$result->fetch_assoc()){
          return $row["fullName"];
      }
    }

    //* [getUserNameArray] it will give us current user name as array
    public function getUserNameArray(){
      $userId = $_SESSION["user_auth_id"];
      $sql="SELECT USER_FIRST_NAME,USER_LAST_NAME from users WHERE USER_ID='$userId'";
      $result = $this->conn->query($sql);
      return $result->fetch_assoc();
    }

   

    // **[getAllUserCount] 
    public function getAllUserCount(){
      $sql="SELECT count(*) as total FROM users WHERE USER_STATUS='Active'";
      $result = $this->conn->query($sql);
      $rows = $result->fetch_all(MYSQLI_ASSOC);
      $this->conn -> close();
      return $rows[0]["total"];
    }

    // **[getAllUsers] 
    public function getAllUsers(){
      $sql="SELECT * FROM users";
      $result = $this->conn->query($sql);
      $rows = $result->fetch_all(MYSQLI_ASSOC);
      return  $rows;
    }

    // * updateUserPassword
    public function updateUserPassword($userId,$currentPassword,$newPassword){
      // check user current password are correct or not
      $sql="SELECT count(*) as total FROM users WHERE USER_ID='$userId' AND  USER_PASSWORD='$currentPassword'";
      $result = $this->conn->query($sql);
      if($row = $result->fetch_assoc()){
        if($row["total"]){
              // *update password
              $sql="UPDATE users SET USER_PASSWORD='$newPassword' WHERE USER_ID='$userId'";
              return $this->conn->query($sql);
        }else{
          return -1;
        }
      }
    }
  }
?>
<?php 
class Review{
    // conn
    private $conn;

    // constructor
    public function __construct($conn){        
        $this->conn = $conn;
    }
     

     // **getAllApprovedApprovals
     public function getAllApprovedApprovals(){
        $sql="SELECT approvals.*, aqflevels.QUALIFIED_DEGREE,staff.TITLE,staff.FIRST_NAME,staff.LAST_NAME,staff.EMAIL,staff.PHONE_NO,staff.STAFF_ADDRESS FROM approvals  left join staff on approvals.STAFF_ID=staff.STAFF_ID left join aqflevels on approvals.AQF_LEVEL_ID=aqflevels.AQF_LEVEL_ID  WHERE approvals.IS_APPROVED='Yes' group by approvals.STAFF_ID  ORDER BY approvals.APPROVAL_ID DESC" ;
       
        $result = $this->conn->query($sql);
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        return $rows;
    }


    
     // **getAllApprovedApprovals
     public function getReviewHistoryByStaffId($staffId){
        $sql="SELECT reviews.*, users.USER_FIRST_NAME FROM reviews  left join USERS on reviews.ADMIN_ID=users.USER_ID  WHERE reviews.STAFF_ID='$staffId'" ;       
        $result = $this->conn->query($sql);
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        return $rows;
    }



    // **insertNewStaffMember
    public function insertNewReview($STAFF_ID,$REVIEW_DATE,$OUTCOME,$NOTES){
        $ADMIN_ID = $_SESSION["user_auth_id"];
        $selectQuery = "SELECT COUNT(*) AS total FROM reviews WHERE REVIEW_DATE='$REVIEW_DATE' AND STAFF_ID='$STAFF_ID'";
        $selectResult = $this->conn->query($selectQuery);
        if($row = $selectResult->fetch_assoc()){
           if($row['total'] == 1){
                 return -1;
           } 
        }
        $sql="INSERT INTO reviews(STAFF_ID,ADMIN_ID,REVIEW_DATE,OUTCOME,NOTES)VALUES('$STAFF_ID','$ADMIN_ID','$REVIEW_DATE','$OUTCOME','$NOTES')";         
         if($this->conn->query($sql)){
             $staffId =  $this->conn->insert_id;
             return $staffId;
         }else{
             return false;
         }
    }

   }
?>
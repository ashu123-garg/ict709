<?php 
 class Location{
      // conn
    private $conn;

    // constructor
    public function __construct($conn){        
        $this->conn = $conn;
    }


    // *getActiveLocation
    public function getActiveLocation(){
        $sql="SELECT * FROM location WHERE STATUS='Active' ORDER BY LOCATION_ID DESC";
        $result = $this->conn->query($sql);
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        return $rows;
    }


    // *insertNewLocation
    public function insertNewLocation($BUILDING_NAME,$STREET_NAME,$CITY,$STATE,$ZIP_CODE,$COUNTRY){
         $sql="INSERT INTO location(BUILDING_NAME,STREET_NAME,CITY,STATE,ZIP_CODE,COUNTRY)VALUES('$BUILDING_NAME','$STREET_NAME','$CITY','$STATE','$ZIP_CODE','$COUNTRY')";
        return $this->conn->query($sql);
    }


    // *setInActiveLocation
    public function setInActiveLocation($location_id){
        $sql = "UPDATE location SET STATUS='InActive' WHERE LOCATION_ID='$location_id'";
        return $this->conn->query($sql);
    }


     // *deleteLocation
     public function deleteLocation($locationId){      
        $sql = "DELETE FROM location WHERE LOCATION_ID='$locationId'";
        return $this->conn->query($sql);        
    }

   
    // *getLocationById
    public function getLocationById($locationId){       
        $sql = "SELECT * FROM location WHERE LOCATION_ID='$locationId'"; 
        $result = $this->conn->query($sql);
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        return $rows;    
    }

    // *updateLocation
    public function updateLocation($location_id,$BUILDING_NAME,$BUILDING_NUMBER,$STREET_NAME,$CITY,$STATE,$ZIP_CODE,$COUNTRY){       
        $sql = "UPDATE LOCATION SET BUILDING_NAME='$BUILDING_NAME',BUILDING_NUMBER='$BUILDING_NUMBER',STREET_NAME='$STREET_NAME',CITY='$CITY',STATE='$STATE',ZIP_CODE='$ZIP_CODE',COUNTRY='$COUNTRY' WHERE LOCATION_ID='$location_id'";
        return $this->conn->query($sql);
    }

    // **[getAllLocationCount] 
    public function getAllLocationCount(){
        $sql="SELECT count(*) as total FROM location WHERE STATUS='Active'";
        $result = $this->conn->query($sql);
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        $this->conn -> close();
        return $rows[0]["total"];
    }

 }

?>
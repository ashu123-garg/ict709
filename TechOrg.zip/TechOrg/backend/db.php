<?php 
  $conn = new mysqli("localhost","root","","techorg");
?>
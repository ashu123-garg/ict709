<?php 
class AqfLevels{
    // conn
    private $conn;

    // constructor
    public function __construct($conn){        
        $this->conn = $conn;
    }
     

    // **get list of all active AqfLevels
    public function getAllActiveAqfLevels(){
        $sql="SELECT * FROM  aqflevels WHERE  AQF_STATUS='Active' ORDER BY QUALIFIED_DEGREE ASC";
        $result = $this->conn->query($sql);
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        $this->conn -> close();
        return $rows;
    }

   

    //**insertAqfLevel
    public function insertAqfLevel($QUALIFIED_DEGREE,$AQF_LEVEL,$QUALIFICATION_LEVEL_REQUIRED_TO_TEACH){  
        $searchValue = strtolower($QUALIFIED_DEGREE);    
        $selectQuery = "SELECT COUNT(*) AS total FROM aqflevels WHERE Lower(QUALIFIED_DEGREE)='$searchValue'";
        $selectResult = $this->conn->query($selectQuery);
        if($row = $selectResult->fetch_assoc()){
           if($row['total'] == 1){
                 return -1;
           } 
        }
        $sql="INSERT INTO aqflevels(QUALIFIED_DEGREE,AQF_LEVEL,QUALIFICATION_LEVEL_REQUIRED_TO_TEACH)VALUES('$QUALIFIED_DEGREE','$AQF_LEVEL','$QUALIFICATION_LEVEL_REQUIRED_TO_TEACH')";
        return $this->conn->query($sql);        
    }

     // **[getAllLAqfLevelCount] 
     public function getAllLAqfLevelCount(){
        $sql="SELECT count(*) as total FROM aqflevels WHERE AQF_STATUS='Active'";
        $result = $this->conn->query($sql);
        $rows = $result->fetch_all(MYSQLI_ASSOC);
        $this->conn -> close();
        return $rows[0]["total"];
    }

}
?>
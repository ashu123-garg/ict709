<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Review - TechOrg</title>
      <!-- include css -->
      <?php include("../includes/externalCss.php") ?>
</head>
<body>
    
<!-- include sidebar -->
<?php
  include("../includes/checkSession.php");
  include("../includes/sidebar.php");  
?>

<div id="main">
    <div class="row">
        <div class="col-md-4">
            <button class="open__btn" id="openBtn" onclick="openNav()">☰ Menu</button>     
            <h2 class="text__primary__color page__heading" id="pageHeadingOpenSidebar"> <i class="fa fa-plus"></i> Add Review</h2>
        </div>
        <div class="col-md-6">
           <h2 class="text__primary__color page__heading" id="pageHeadingCloseSidebar"><i class="fa fa-plus"></i> Add Review</h2>
        </div>
        <div class="col-md-2">
              <a href="#" onclick="goBack()" class="add__btn"> <i class="fa fa-angle-left"></i> Back</a>
        </div>
    </div>
      <hr/>
     <div class="page__content">
         <div class="card">
             <div class="card-body">
                 <form action="" method="post">
                       <div class="row">
                           <div class="col-md-4">
                               <div class="form-group">
                                   <label for="REVIEW_DATE">Review Date*</label>
                                   <input type="date" name="REVIEW_DATE" id="REVIEW_DATE" class="form-control" placeholder="Review Date" required/>
                               </div>
                           </div>

                           <div class="col-md-4">
                               <div class="form-group">
                                   <label for="OUTCOME">AQF Level*</label>
                                   <select name="OUTCOME" id="OUTCOME" class="form-control"  required>
                                        <option value="">Select Outcome</option>
                                        <option >Continue</option>
                                        <option >Warning</option>
                                        <option >Terminate</option>                                                                            
                                   </select>
                               </div>
                           </div>

                           <div class="col-md-4">
                               <div class="form-group">
                                   <label for="NOTES">Notes*</label>
                                   <textarea name="NOTES" id="NOTES" class="form-control" placeholder="Review Note" required></textarea>                                       
                               </div>
                           </div>


                           <!-- final buttons -->
                        <div class="col-md-12">
                               <button type="submit" name="addNewReview" class="add__btn">
                                    <i class="fa fa-save"></i> Add Review
                               </button>

                               <button type="Reset" class="add__btn">
                                    <i class="fa fa-window-restore"></i> Reset
                               </button>
                        </div>

                       </div>
                 </form>
             </div>
         </div>
     </div>
</div>

  <!-- include js -->
  <?php include("../includes/externalJs.php");?>
<script>
function goBack() {
  window.history.back();
}

 </script>
</body>

<?php 
   if(isset($_POST["addNewReview"])){
    $REVIEW_DATE=$_POST["REVIEW_DATE"];
    $OUTCOME=$_POST["OUTCOME"];
    $NOTES=$_POST["NOTES"];
    $STAFF_ID = $_GET["staffId"];

    
   include("../../backend/Review.php");
   include("../../backend/db.php");
   $review = new Review($conn);
   $reviewInsertResult = $review->insertNewReview($STAFF_ID,$REVIEW_DATE,$OUTCOME,$NOTES);
   if($reviewInsertResult === -1){    
    ?>
    <script>
           $(".error__message").text("Oops! Review Already Exist.");
           $('#errorModal').modal('show'); 
    </script>
    <?php 
   }else if($reviewInsertResult){    
    ?>
    <script>
        $(".success__message").text("New Review Added Successfully!");
        $('#successModal').modal('show');
    </script>
    <?php
   }else{
    //    show eerror
   ?>
     <script>
         $(".error__message").text("Oops! Something Went Wrong.");
         $('#errorModal').modal('show');
     </script>
   <?php
   } 
    

    ?>
    <script>history.pushState({}, "", "")</script>
    <?php
   }
   
?>
</html>

<?php
  include("../includes/checkSession.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review History- TechOrg</title>
      <!-- include css -->
      <?php 
        include("../includes/externalCss.php"); 
        include("../includes/dataTableCss.php"); 
        include("../../backend/db.php");
        include("../../backend/Review.php");
        $review = new Review($conn);
      ?>
      
</head>
<body>
    
<!-- include sidebar -->
<?php include("../includes/sidebar.php") ?>
<div id="main">
    <div class="row">
        <div class="col-md-2">
            <button class="open__btn" id="openBtn" onclick="openNav()">☰ Menu</button>     
            <h2 class="text__primary__color page__heading" id="pageHeadingOpenSidebar"> <i class="fa fa-history"></i> Review History</h2>
        </div>
        <div class="col-md-8">
           <h2 class="text__primary__color page__heading" id="pageHeadingCloseSidebar"><i class="fa fa-history"></i> Review History</h2>
        </div>
        <div class="col-md-2">
              <a href="addReview.php?staffId=<?php echo $_GET['staffId'];?>" class="add__btn"> <i class="fa fa-plus"></i> Add Review</a>
        </div>
    </div>
      <hr/>
     <div class="page__content">
          <div id="myTableWrapper" class="table-responsive">
            <table class="table stripe display nowrap" id="myTable">
                <thead class="thead bg__primary__color">
                    <tr>
                        <th>Sr. No.</th>
                        <th>Emp Id</th>
                        <th>Review Date</th>
                        <th>Outcome</th>
                        <th>Note</th>
                        <th>Create At</th>
                        <th>Update At</th>
                        <th>Reviewed By</th>                                              
                    </tr>
                </thead>
                
                <tbody>
                    <?php 
                       $staffId = $_GET["staffId"];
                       $reviewData = $review->getReviewHistoryByStaffId($staffId);
                       $srNo= 1;
                       foreach($reviewData as $reviewInfo){
                            ?>
                            <tr>
                                <td class="font__weight"><?php echo $srNo; ?></td>
                                <td class="font__weight"><?php echo $reviewInfo["STAFF_ID"]; ?></td>
                                <td class="font__weight"><?php echo $reviewInfo["REVIEW_DATE"]; ?></td>
                                <td class="font__weight"><?php echo $reviewInfo["OUTCOME"]; ?></td>
                                <td class="font__weight"><?php echo $reviewInfo["NOTES"]; ?></td>
                                <td class="font__weight"><?php echo $reviewInfo["CREATE_AT"]; ?></td>
                                <td class="font__weight"><?php echo $reviewInfo["UPDATE_AT"]; ?></td>
                                <td class="font__weight"><?php echo $reviewInfo["USER_FIRST_NAME"]; ?></td>
                            </tr>
                            <?php
                            $srNo++;
                       }
                    ?>
                </tbody>

            </table>
          </div>
     </div>
</div>
    <!-- include js -->
<?php 
   include("../includes/externalJs.php");
   include("../includes/dataTableJs.php");
?>
</body>
</html>
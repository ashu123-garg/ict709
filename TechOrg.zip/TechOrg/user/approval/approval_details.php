<?php
  include("../includes/checkSession.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Approval Details - TechOrg</title>
      <!-- include css -->
      <?php 
        include("../includes/externalCss.php"); 
        include("../../backend/db.php");
        include("../../backend/Approvals.php");
        $approvals = new Approvals($conn);
      ?>
      
</head>
<body>
    
<!-- include sidebar -->
<?php include("../includes/sidebar.php") ?>
<div id="main">
    <div class="row">
        <div class="col-md-4">
            <button class="open__btn" id="openBtn" onclick="openNav()">☰ Menu</button>     
            <h2 class="text__primary__color page__heading" id="pageHeadingOpenSidebar"> <i class="fa fa-check-circle"></i> Approval Request Details <i class="fa fa-print" onclick="window.print()"></i> </h2>
        </div>
        <div class="col-md-6">
           <h2 class="text__primary__color page__heading" id="pageHeadingCloseSidebar"><i class="fa fa-check-circle"></i> Approval Request Details <i class="fa fa-print" onclick="window.print()"></i></h2>
        </div>
        <div class="col-md-2">
              <!-- <a href="http://localhost/techOrg/user/staff/insertStaff.php" class="add__btn"> <i class="fa fa-plus"></i> Add Staff</a> -->
        </div>
    </div>
      <hr/>
     <div class="page__content">
          <div id="" class="table-responsive">
               <h3>Personal Info</h3>
            <table class="table table-striped" id="">
                <thead class="thead bg__primary__color">
                    <tr>
                        <th>Sr. No.</th>
                        <th>Staff ID</th>
                        <th>Title</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Address</th>
                    </tr>
                </thead>
                
                <tbody>
                    <?php 
                       $reqId = $_GET["req_id"];
                       $approvalData = $approvals->getApprovalsDetailsById($reqId);
                       $srNo= 1;
                       foreach($approvalData as $approvalInfo){
                            ?>
                            <tr>
                                <td class="font__weight"><?php echo $srNo; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["STAFF_ID"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["TITLE"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["FIRST_NAME"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["LAST_NAME"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["EMAIL"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["PHONE_NO"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["STAFF_ADDRESS"]; ?></td>
                            </tr>
                            <?php
                            $srNo++;
                       }
                    ?>
                </tbody>

            </table>
          </div>
          <hr/>

          <div id="" class="table-responsive">
               <h3>AQF Level Info</h3>
            <table class="table table-striped" id="">
                <thead class="thead bg__primary__color">
                    <tr>
                        <th>Sr. No.</th>
                        <th>Qualification</th>
                        <th>AQF Level</th>
                        <th>Required Qualification Level To Teach</th>
                    </tr>
                </thead>
                
                <tbody>
                    <?php 
                    //    $reqId = $_GET["req_id"];
                    //    $approvalData = $approvals->getApprovalsDetailsById($reqId);
                       $srNo= 1;
                       foreach($approvalData as $approvalInfo){
                            ?>
                            <tr>
                                <td class="font__weight"><?php echo $srNo; ?></td>                               
                                <td class="font__weight"><?php echo $approvalInfo["QUALIFIED_DEGREE"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["AQF_LEVEL"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["QUALIFICATION_LEVEL_REQUIRED_TO_TEACH"]; ?></td>
                            </tr>
                            <?php
                            $srNo++;
                       }
                    ?>
                </tbody>

            </table>
          </div>
          <hr/>


          <div id="" class="table-responsive">
               <h3>Approval Details</h3>
            <table class="table table-striped" id="">
                <thead class="thead bg__primary__color">
                    <tr>
                        <th>Sr. No.</th>
                        <th>STAFF ID</th>
                        <th>IS APPROVED</th>
                        <th>APPROVE DATE</th>
                        <th>NEXT REVIEW DATE</th>
                        <th>APPROVE BY</th>
                        <th>APPROVAL STATUS</th>
                        <th>NOTES</th>
                    </tr>
                </thead>
                
                <tbody>
                    <?php                    
                       $srNo= 1;
                       foreach($approvalData as $approvalInfo){
                            ?>
                            <tr>
                                <td class="font__weight"><?php echo $srNo; ?></td>                               
                                <td class="font__weight"><?php echo $approvalInfo["STAFF_ID"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["IS_APPROVED"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["APPROVE_DATE"] =="0000-00-00" ? "N/A": $approvalInfo["APPROVE_DATE"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["NEXT_REVIEW_DATE"] =="0000-00-00" ? "N/A": $approvalInfo["NEXT_REVIEW_DATE"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["APPROVE_BY"] == 0 ? 'N/A' :  $approvalInfo["APPROVE_BY"]; ?></td>
                                <td class="font__weight <?php echo $approvalInfo["APPROVAL_STATUS"]=="Pending"? 'text-warning': $approvalInfo["APPROVAL_STATUS"]=="Rejected"? 'text-danger':'text-success' ; ?>"><?php echo $approvalInfo["APPROVAL_STATUS"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["NOTES"] == '' ? 'N/A' : $approvalInfo["NOTES"]; ?></td>
                            </tr>
                            <?php
                            $srNo++;
                       }
                    ?>
                </tbody>

            </table>
          </div>
          <hr/>

        <?php 
        //    if request approved        
           if($approvalInfo["IS_APPROVED"] =="Yes"){
                 ?>
                 <div id="" class="table-responsive">
                    <h3> Approve Location Details</h3>
                    <table class="table table-striped" id="">
                        <thead class="thead bg__primary__color">
                            <tr>
                                <th>Sr. No.</th>
                                <th>Building Name</th>
                                <th>Street Name</th>
                                <th>City</th>
                                <th>State</th>
                                <th>Zip Code</th>
                                <th>Country</th>
                            </tr>
                        </thead>
                        
                        <tbody>
                            <?php                    
                            $srNo= 1;
                            $locationData = $approvals->getLocationDetailsById($approvalInfo["LOCATION_ID"]);
                            foreach($locationData as $locationInfo){
                                    ?>
                                    <tr>
                                        <td class="font__weight"><?php echo $srNo; ?></td>                               
                                        <td class="font__weight"><?php echo $locationInfo["BUILDING_NAME"]; ?></td>
                                        <td class="font__weight"><?php echo $locationInfo["STREET_NAME"]; ?></td>
                                        <td class="font__weight"><?php echo $locationInfo["CITY"]; ?></td>
                                        <td class="font__weight"><?php echo $locationInfo["STATE"]; ?></td>
                                        <td class="font__weight"><?php echo $locationInfo["ZIP_CODE"]; ?></td>
                                        <td class="font__weight"><?php echo $locationInfo["COUNTRY"]; ?></td>
                                    
                                    </tr>
                                    <?php
                                    $srNo++;
                            }
                            ?>
                        </tbody>

                    </table>
                 </div>
                 <hr/>

                 <div id="" class="table-responsive">
                    <h3>Approve AQF Level</h3>
                    <table class="table table-striped" id="">
                        <thead class="thead bg__primary__color">
                            <tr>
                                <th>Sr. No.</th>
                                <th>Qualified Degree</th>
                                <th>AQF Level</th>
                                <th>Level Required</th>
                            </tr>
                        </thead>
                        
                        <tbody>
                            <?php                    
                            $srNo= 1;
                            $approvedAqfLevelData = $approvals->getApprovedAqfLevelById($approvalInfo["APPROVED_AQF_LEVEL_ID"]);
                            foreach($approvedAqfLevelData as $approvedAqfLevelInfo){
                                    ?>
                                    <tr>
                                        <td class="font__weight"><?php echo $srNo; ?></td>                               
                                        <td class="font__weight"><?php echo $approvedAqfLevelInfo["QUALIFIED_DEGREE"]; ?></td>
                                        <td class="font__weight"><?php echo $approvedAqfLevelInfo["AQF_LEVEL"]; ?></td>
                                        <td class="font__weight"><?php echo $approvedAqfLevelInfo["QUALIFICATION_LEVEL_REQUIRED_TO_TEACH"]; ?></td>
                                    </tr>
                                    <?php
                                    $srNo++;
                            }
                            ?>
                        </tbody>

                    </table>
                 </div>
                 <hr/>
                

                 <?php
           }
        ?>

          <div id="" class="table-responsive">
               <h3>Qualification Details</h3>
            <table class="table table-striped" id="">
                <thead class="thead bg__primary__color">
                    <tr>
                        <th>Qualification</th>
                        <th>Subject Area</th>
                        <th>Institution Name</th>
                        <th>Institution Country</th>
                        <th>Award Full Name</th>
                        <th>Award Year</th>
                        <th>AQF Level</th>
                        <th>Required Level</th>
                    </tr>
                </thead>
                
                <tbody>
                    <?php                    
                       $reqId = $_GET["req_id"];
                       $qualificationData = $approvals->getQualificationDetailsByStaffId($approvalInfo["STAFF_ID"]);
                       foreach($qualificationData as $qualificationInfo){
                            ?>
                            <tr>
                                <td class="font__weight"><?php echo $qualificationInfo["QUALIFIED_DEGREE"]; ?></td>
                                <td class="font__weight"><?php echo $qualificationInfo["SUBJECT_AREA"]; ?></td>
                                <td class="font__weight"><?php echo $qualificationInfo["INSTITUTION_NAME"]; ?></td>
                                <td class="font__weight"><?php echo $qualificationInfo["INSTITUTION_COUNTRY"]; ?></td>
                                <td class="font__weight"><?php echo $qualificationInfo["FULL_NAME_OF_AWARD"]; ?></td>
                                <td class="font__weight"><?php echo $qualificationInfo["AWARDED_YEAR"]; ?></td>
                                <td class="font__weight"><?php echo $qualificationInfo["AQF_LEVEL"]; ?></td>
                                <td class="font__weight"><?php echo $qualificationInfo["QUALIFICATION_LEVEL_REQUIRED_TO_TEACH"]; ?></td>
                            </tr>
                            <?php
                       }
                    ?>
                </tbody>

            </table>
          </div>
          <hr/>


          <div id="" class="table-responsive">
               <h3>Teaching Experience</h3>
            <table class="table table-striped" id="">
                <thead class="thead bg__primary__color">
                    <tr>
                        <th>Joining Date</th>
                        <th>Finish Date</th>
                        <th>Institution Name</th>
                        <th>Institution Country</th>
                        <th>Role</th>
                    </tr>
                </thead>
                
                <tbody>
                    <?php                    
                       $reqId = $_GET["req_id"];
                       $teachingData = $approvals->getTeachingExperienceByStaffId($approvalInfo["STAFF_ID"]);
                       foreach($teachingData as $teachingInfo){
                            ?>
                            <tr>
                                <td class="font__weight"><?php echo $teachingInfo["JOINING_DATE"]; ?></td>
                                <td class="font__weight"><?php echo $teachingInfo["FINISH_DATE"]; ?></td>
                                <td class="font__weight"><?php echo $teachingInfo["INSTITUTION_NAME"]; ?></td>
                                <td class="font__weight"><?php echo $teachingInfo["INSTITUTION_COUNTRY"]; ?></td>
                                <td class="font__weight"><?php echo $teachingInfo["ROLE"]; ?></td>                                
                            </tr>
                            <?php
                       }
                    ?>
                </tbody>

            </table>
          </div>
          <hr/>

          <div id="" class="table-responsive">
               <h3>Relevent Employement Experience</h3>
            <table class="table table-striped" id="">
                <thead class="thead bg__primary__color">
                    <tr>
                        <th>Joining Date</th>
                        <th>Finish Date</th>
                        <th>Employment Type</th>
                        <th>Employer Name</th>
                        <th>Position Title</th>
                        <th>Relevant Duties</th>
                    </tr>
                </thead>
                
                <tbody>
                    <?php                    
                       $relavantData = $approvals->getRelevantEmployementExperienceByStaffId($approvalInfo["STAFF_ID"]);
                       if(!count($relavantData)){
                        ?>
                          <tr><td class="font__weight text-center" colspan="6">Data Not Found!</td></tr>
                        <?php 
                        }
                       foreach($relavantData as $relavantInfo){
                            ?>
                            <tr>
                                <td class="font__weight"><?php echo $relavantInfo["JOINING_DATE"]; ?></td>
                                <td class="font__weight"><?php echo $relavantInfo["FINISH_DATE"]; ?></td>
                                <td class="font__weight"><?php echo $relavantInfo["EMPLOYMENT_TYPE"]; ?></td>
                                <td class="font__weight"><?php echo $relavantInfo["EMPLOYER_NAME"]; ?></td>
                                <td class="font__weight"><?php echo $relavantInfo["POSITION_TITLE"]; ?></td>                                
                                <td class="font__weight"><?php echo $relavantInfo["RELEVANT_DUTIES"]; ?></td>                                
                            </tr>
                            <?php
                       }
                    ?>
                </tbody>

            </table>
          </div>
          <hr/>

            <div id="" class="table-responsive">
               <h3>Publication Details</h3>
            <table class="table table-striped" id="">
                <thead class="thead bg__primary__color">
                    <tr>
                        <th>Author Surname</th>
                        <th>Initial</th>
                        <th>Publication Year</th>
                        <th>Title</th>
                        <th>Type</th>
                        <th>Reviewed</th>
                        <th>Classification</th>
                        <th>Broad Field</th>
                    </tr>
                </thead>
                
                <tbody>
                    <?php                    
                       $publicationData = $approvals->getPublicationDetailsByStaffId($approvalInfo["STAFF_ID"]);
                       if(!count($publicationData)){
                        ?>
                          <tr><td class="font__weight text-center" colspan="6">Data Not Found!</td></tr>
                        <?php 
                        }
                       foreach($publicationData as $publicationInfo){
                            ?>
                            <tr>
                                <td class="font__weight"><?php echo $publicationInfo["AUTHOR_SURNAME"]; ?></td>
                                <td class="font__weight"><?php echo $publicationInfo["AUTHOR_INITIAL"]; ?></td>
                                <td class="font__weight"><?php echo $publicationInfo["YEAR_OF_PUBLICATION"]; ?></td>
                                <td class="font__weight"><?php echo $publicationInfo["TITLE_OF_PUBLICATION"]; ?></td>
                                <td class="font__weight"><?php echo $publicationInfo["TYPE_OF_PUBLICATION"]; ?></td>                                
                                <td class="font__weight"><?php echo $publicationInfo["PEER_REVIEWED"]; ?></td>                                
                                <td class="font__weight"><?php echo $publicationInfo["CLASSIFICATION"]; ?></td>                                
                                <td class="font__weight"><?php echo $publicationInfo["BROAD_FIELD_EDUCATION"]; ?></td>                                
                            </tr>
                            <?php
                       }
                    ?>
                </tbody>

            </table>
          </div>
          <hr/>

          <div id="" class="table-responsive">
               <h3>Documents Details</h3>
            <table class="table table-striped" id="">
                <thead class="thead bg__primary__color">
                    <tr>
                        <th>Sr. No.</th>
                        <th>Document Name</th>
                        <th>Create By</th>
                        <th>Create Date</th>
                    </tr>
                </thead>
                
                <tbody>
                    <?php                    
                       $relavantData = $approvals->getDocumentDetailsByStaffId($approvalInfo["STAFF_ID"]);
                       $srNo=1;
                       if(!count($relavantData)){
                        ?>
                          <tr><td class="font__weight text-center" colspan="6">Data Not Found!</td></tr>
                        <?php 
                        }
                       foreach($relavantData as $relavantInfo){
                            ?>
                            <tr>
                                <td class="font__weight"><?php echo $srNo; ?></td>
                                <td class="font__weight"><?php echo $relavantInfo["DOCS_NAME"]; ?></td>
                                <td class="font__weight"><?php echo $relavantInfo["USER_FIRST_NAME"]; ?></td>
                                <td class="font__weight"><?php echo $relavantInfo["DOCUMENT_CREATE_AT"]; ?></td>                                                               
                            </tr>
                            <?php
                            $srNo++;
                       }
                    ?>
                </tbody>

            </table>
          </div>
          <hr/>

          <div id="" class="table-responsive">
               <h3>Other Relevant Info</h3>
            <table class="table table-striped" id="">
                <thead class="thead bg__primary__color">
                    <tr>
                        <th>Sr. No.</th>
                        <th>Relevant Info</th>
                    </tr>
                </thead>
                
                <tbody>
                    <?php                    
                       $relavantData = $approvals->getOtherRelevantInfoByStaffId($approvalInfo["STAFF_ID"]);
                       $srNo=1;
                       if(!count($relavantData)){
                        ?>
                          <tr><td class="font__weight text-center" colspan="6">Data Not Found!</td></tr>
                        <?php 
                        }
                       foreach($relavantData as $relavantInfo){
                            ?>
                            <tr>
                                <td class="font__weight"><?php echo $srNo; ?></td>
                                <td class="font__weight"><?php echo $relavantInfo["RELEVANT_INFO"]; ?></td>
                            </tr>
                            <?php
                            $srNo++;
                       }
                    ?>
                </tbody>

            </table>
          </div>
          <hr/>


          <?php
             if($approvalInfo["APPROVAL_STATUS"]==="Pending"){
                 ?>
                                <!-- approved modal button -->
                <div class="row">
                    <div class="col-12">
                            <button type="submit" class="btn btn-success" data-toggle="modal" data-target="#approveModal"> <i class="fa fa-check-circle"></i> Approved Request</button>
                            <button type="submit" class="btn btn-danger" data-toggle="modal" data-target="#rejectModal"> <i class="fa fa-times-circle"></i> Reject Request</button>
                    </div>
                </div>

                 <?php 
             }else{
                 ?>
                 <div class="row">
                    <div class="col-12">
                         <div class="alert <?php echo  $approvalInfo["APPROVAL_STATUS"]==="Rejected" ? 'alert-danger' :'alert-info'; ?> ">
                                 <?php
                                    if($approvalInfo["APPROVAL_STATUS"]==="Rejected"){
                                        ?>
                                        <h3> <i class="fa fa-times-circle"></i> :( Sorry Your Request Rejected.</h3>
                                        <?php
                                    }else{
                                        ?>
                                        <h3> <i class="fa fa-check-circle"></i>Congratulations! Your Request Are Approved.</h3>
                                        <?php
                                    }
                                 ?>
                         </div>
                    </div>
                </div>
                 <?php 
             }
          ?>

     
     </div>
</div>

<!-- modals -->

<!--reject Modal -->
<div class="modal fade" id="rejectModal" data-backdrop="static" data-keyboard="false"  tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Reject Request</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
               <form action="" method="post">
                  <input type="hidden" name="APPROVAL_ID" value="<?php echo $_GET["req_id"]; ?>">
                   <div class="row">
                       <div class="col-md-12">
                           <div class="form-group">
                               <label for="REJECT_NOTE">Reject Note*</label>
                               <textarea name="REJECT_NOTE" id="REJECT_NOTE" class="form-control" placeholder="Your Note" required></textarea>
                           </div>
                       </div>
                     
                   <button type="submit"  name="reject_btn" class="add__btn btn-block"> <i class="fa fa-times-circle"></i> Reject Request</button>

               </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="add__btn" data-dismiss="modal"> <i class="fa fa-times"></i> Close</button>
      </div>
    </div>
  </div>
</div>
            </div>
<!--Approve Modal -->
<div class="modal fade" id="approveModal" data-backdrop="static" data-keyboard="false"  tabindex="-1" role="dialog" aria-labelledby="approvedModal" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Approve Request</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
         <form action="" method="post">
                  <input type="hidden" name="STAFF_ID" value="<?php echo $approvalInfo["STAFF_ID"]; ?>">
                  <input type="hidden" name="APPROVAL_ID" value="<?php echo $_GET["req_id"]; ?>">
                   <div class="row">
                       <div class="col-md-12">
                           <div class="form-group">
                               <label for="LOCATION_ID">Location</label>
                               <select name="LOCATION_ID" id="LOCATION_ID" class="form-control"  required>
                                   <option value="">Select Staff Location</option>
                                   <?php 
                                     $locations =  $approvals->getAllActiveLocations();
                                     foreach($locations as $location){
                                         ?>
                                         <option value="<?php echo $location['LOCATION_ID'];?>"><?php echo $location['BUILDING_NAME'];?> </option>
                                         <?php 
                                     }
                                   ?>
                                </select>
                           </div>
                       </div>   
                       <div class="col-md-12">
                           <div class="form-group">
                               <label for="APPROVED_AQF_LEVEL_ID">Approved AQF Level</label>
                               <select name="APPROVED_AQF_LEVEL_ID" id="APPROVED_AQF_LEVEL_ID" class="form-control"  required>
                                   <option value="">Select Approved AQF Level</option>
                                   <?php 
                                     $aqfLevels =  $approvals->getAllActiveAqfLevels();
                                     foreach($aqfLevels as $aqfLevel){
                                         ?>
                                         <option value="<?php echo $aqfLevel['AQF_LEVEL_ID'];?>"><?php echo $aqfLevel['QUALIFIED_DEGREE'].'('.$aqfLevel['QUALIFICATION_LEVEL_REQUIRED_TO_TEACH'].')';?> </option>
                                         <?php 
                                     }

                                   ?>
                               </select>
                           </div>                           
                       </div>
                       <div class="col-md-12">
                            <div class="form-group">
                                <label for="APPROVE_NOTE">Approver Note*</label>
                                <textarea name="APPROVE_NOTE" id="APPROVE_NOTE" class="form-control" placeholder="Your Note" required></textarea>
                            </div>
                        </div>    

                       <div class="col-md-12">
                           <div class="form-group">
                               <label for="REVIEW_DATE">Next Review Date</label>
                               <input type="date" name="REVIEW_DATE" id="REVIEW_DATE" class="form-control" placeholder="Review Date" required>
                           </div>
                       </div>   
                   </div>
                   <button type="submit" name="Approved_Btn" class="add__btn btn-block"> <i class="fa fa-check-circle"></i> Approved Request</button>

               </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="add__btn" data-dismiss="modal"> <i class="fa fa-times"></i> Close</button>
      </div>
    </div>
  </div>
</div>

    <!-- include js -->
<?php 
   include("../includes/externalJs.php");
?>

<?php 
// if reject btn pressed
  if(isset($_POST["REJECT_NOTE"])){
      $APPROVAL_ID = $_POST["APPROVAL_ID"];
      $REJECT_NOTE = $_POST["REJECT_NOTE"];
      $rejectRequestResult = $approvals->rejectApprovalRequest($APPROVAL_ID,$REJECT_NOTE);
      if($rejectRequestResult){
        ?>
        <script>
            $(".success__message").text("Request Rejected Successfully!");
            $('#successModal').modal('show');
        </script>
        <?php
       }else{
        //    show eerror
       ?>
         <script>
             $(".error__message").text("Oops! Something Went Wrong.");
             $('#errorModal').modal('show');
         </script>
       <?php
       } 
       ?>
    <script>history.pushState({}, "", "");window.location.reload();</script>
    <?php
  }
// if approved btn pressed
  if(isset($_POST["Approved_Btn"])){
    $APPROVAL_ID = $_POST["APPROVAL_ID"];
    $LOCATION_ID = $_POST["LOCATION_ID"];
    $APPROVED_AQF_LEVEL_ID = $_POST["APPROVED_AQF_LEVEL_ID"];
    $APPROVE_NOTE = $_POST["APPROVE_NOTE"];
    $REVIEW_DATE = $_POST["REVIEW_DATE"];
    $approvedRequestResult = $approvals->approvedApprovalRequest($APPROVAL_ID,$LOCATION_ID,$APPROVED_AQF_LEVEL_ID,$REVIEW_DATE,$APPROVE_NOTE);
    if($approvedRequestResult){
      ?>
      <script>
          $(".success__message").text("Request Rejected Successfully!");
          $('#successModal').modal('show');
      </script>
      <?php
     }else{
      //    show eerror
     ?>
       <script>
           $(".error__message").text("Oops! Something Went Wrong.");
           $('#errorModal').modal('show');
       </script>
     <?php
     } 
     ?>
  <script>
  history.pushState({}, "", "");
  setTimeout(() => {
    window.location.href='http://localhost/techOrg/user/approval';
  }, 3000);
</script>
  <?php
}
?>
</body>
</html>
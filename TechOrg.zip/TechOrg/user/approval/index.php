<?php
  include("../includes/checkSession.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Approval - TechOrg</title>
      <!-- include css -->
      <?php 
        include("../includes/externalCss.php"); 
        include("../includes/dataTableCss.php"); 
        include("../../backend/db.php");
        include("../../backend/Approvals.php");
        $approvals = new Approvals($conn);
      ?>
      
</head>
<body>
    
<!-- include sidebar -->
<?php include("../includes/sidebar.php") ?>
<div id="main">
    <div class="row">
        <div class="col-md-2">
            <button class="open__btn" id="openBtn" onclick="openNav()">☰ Menu</button>     
            <h2 class="text__primary__color page__heading" id="pageHeadingOpenSidebar"> <i class="fa fa-check-circle"></i> Approvals</h2>
        </div>
        <div class="col-md-8">
           <h2 class="text__primary__color page__heading" id="pageHeadingCloseSidebar"><i class="fa fa-check-circle"></i> Approvals</h2>
        </div>
        <div class="col-md-2">
              <!-- <a href="http://localhost/techOrg/user/staff/insertStaff.php" class="add__btn"> <i class="fa fa-plus"></i> Add Staff</a> -->
        </div>
    </div>
      <hr/>
     <div class="page__content">
          <div id="myTableWrapper" class="table-responsive">
            <table class="table stripe display nowrap" id="myTable">
                <thead class="thead bg__primary__color">
                    <tr>
                        <th>Sr. No.</th>
                        <th>Staff ID</th>
                        <th>Title</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Qualification</th>
                        <th>Status</th>
                        <th>Action</th>                        
                    </tr>
                </thead>
                
                <tbody>
                    <?php 
                       $approvalData = $approvals->getAllPendingApprovals();
                       $srNo= 1;
                       foreach($approvalData as $approvalInfo){
                            ?>
                            <tr>
                                <td class="font__weight"><?php echo $srNo; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["STAFF_ID"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["TITLE"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["FIRST_NAME"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["LAST_NAME"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["EMAIL"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["PHONE_NO"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["QUALIFIED_DEGREE"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["APPROVAL_STATUS"]; ?></td>
                                <td>
                                    <?php 
                                       $reqId =$approvalInfo["APPROVAL_ID"];
                                    ?>
                                   <button class="btn btn-dark rounded-circle" onclick="window.location.href='./approval_details.php?req_id=<?php echo $reqId; ?>'"> <i class="fa fa-eye"></i></button>
                                </td>
                            </tr>
                            <?php
                            $srNo++;
                       }
                    ?>
                </tbody>

            </table>
          </div>
     </div>
</div>
    <!-- include js -->
<?php 
   include("../includes/externalJs.php");
   include("../includes/dataTableJs.php");
?>
</body>
</html>
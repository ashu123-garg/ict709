<?php
  include("../includes/checkSession.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AQF Levels - TechOrg</title>
      <!-- include css -->
      <?php 
        include("../includes/externalCss.php"); 
        include("../includes/dataTableCss.php"); 
        include("../../backend/db.php");
        include("../../backend/Aqflevels.php");
        $aqflevels = new Aqflevels($conn);
      ?>
      
</head>
<body>
    
<!-- include sidebar -->
<?php include("../includes/sidebar.php") ?>
<div id="main">
    <div class="row">
        <div class="col-md-2">
            <button class="open__btn" id="openBtn" onclick="openNav()">☰ Menu</button>     
            <h2 class="text__primary__color page__heading" id="pageHeadingOpenSidebar"> <i class="fa fa-building"></i> AQF Level</h2>
        </div>
        <div class="col-md-8">
           <h2 class="text__primary__color page__heading" id="pageHeadingCloseSidebar"><i class="fa fa-building"></i> AQF Level</h2>
        </div>
        <div class="col-md-2">
              <a href="http://localhost/techOrg/user/aqf/addAqf.php" class="add__btn"> <i class="fa fa-plus"></i> Add AQF</a>
        </div>
    </div>
      <hr/>
     <div class="page__content">
          <div id="myTableWrapper" class="table-responsive">
            <table class="table stripe display nowrap" id="myTable">
                <thead class="thead bg__primary__color">
                    <tr>
                        <th>Sr. No.</th>
                        <th>Qualified Degree</th>
                        <th>AQF Level</th>
                        <th>Qualification Level Required</th>
                        <th>Status</th>
                    </tr>
                </thead>
                
                <tbody>
                    <?php 
                       $srNo= 1;
                       $aqflevelData = $aqflevels->getAllActiveAqfLevels();
                       foreach($aqflevelData as $aqflevel){
                            ?>
                            <tr>
                                <td class="font__weight"><?php echo $srNo; ?></td>
                                <td class="font__weight"><?php echo $aqflevel["QUALIFIED_DEGREE"]; ?></td>
                                <td class="font__weight"><?php echo $aqflevel["AQF_LEVEL"]; ?></td>
                                <td class="font__weight"><?php echo $aqflevel["QUALIFICATION_LEVEL_REQUIRED_TO_TEACH"]; ?></td>
                                <td class="font__weight"><?php echo $aqflevel["AQF_STATUS"]; ?></td>
                            </tr>
                            <?php
                            $srNo++;
                       }
                    ?>
                </tbody>

            </table>
          </div>
     </div>
</div>
    <!-- include js -->
<?php 
   include("../includes/externalJs.php");
   include("../includes/dataTableJs.php");
?>
</body>
</html>
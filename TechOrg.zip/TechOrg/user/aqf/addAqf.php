<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add AQF - TechOrg</title>
      <!-- include css -->
      <?php include("../includes/externalCss.php") ?>
</head>
<body>
    
<!-- include sidebar -->
<?php
  include("../includes/checkSession.php");
  include("../includes/sidebar.php");  
?>

<div id="main">
    <div class="row">
        <div class="col-md-4">
            <button class="open__btn" id="openBtn" onclick="openNav()">☰ Menu</button>     
            <h2 class="text__primary__color page__heading" id="pageHeadingOpenSidebar"> <i class="fa fa-plus"></i> Add AQF Level</h2>
        </div>
        <div class="col-md-6">
           <h2 class="text__primary__color page__heading" id="pageHeadingCloseSidebar"><i class="fa fa-plus"></i> Add AQF Level</h2>
        </div>
        <div class="col-md-2">
              <a href="#" onclick="goBack()" class="add__btn"> <i class="fa fa-angle-left"></i> Back</a>
        </div>
    </div>
      <hr/>
     <div class="page__content">
         <div class="card">
             <div class="card-body">
                 <form action="" method="post">
                       <div class="row">
                           <div class="col-md-4">
                               <div class="form-group">
                                   <label for="QUALIFIED_DEGREE">Qulified Degree*</label>
                                   <input type="text" name="QUALIFIED_DEGREE" id="QUALIFIED_DEGREE" class="form-control" placeholder="Qulified Degree" required/>
                               </div>
                           </div>

                           <div class="col-md-4">
                               <div class="form-group">
                                   <label for="AQF_LEVEL">AQF Level*</label>
                                   <select name="AQF_LEVEL" id="AQF_LEVEL" class="form-control"  required>
                                        <option value="">Select AQF Level</option>
                                        <option value="1">Level 1</option>
                                        <option value="2">Level 2</option>
                                        <option value="3">Level 3</option>
                                        <option value="4">Level 4</option>
                                        <option value="5">Level 5</option>
                                        <option value="6">Level 6</option>
                                        <option value="7">Level 7</option>
                                        <option value="8">Level 8</option>
                                        <option value="9">Level 9</option>
                                        <option value="10">Level 10</option>                                        
                                   </select>
                               </div>
                           </div>

                           <div class="col-md-4">
                               <div class="form-group">
                                   <label for="QUALIFICATION_LEVEL_REQUIRED_TO_TEACH">Required Qualification Level*</label>
                                   <select name="QUALIFICATION_LEVEL_REQUIRED_TO_TEACH" id="QUALIFICATION_LEVEL_REQUIRED_TO_TEACH" class="form-control" required>
                                        <option value="">Select Required Qualification Level</option>
                                        <option value="1">Level 1</option>
                                        <option value="2">Level 2</option>
                                        <option value="3">Level 3</option>
                                        <option value="4">Level 4</option>
                                        <option value="5">Level 5</option>
                                        <option value="6">Level 6</option>
                                        <option value="7">Level 7</option>
                                        <option value="8">Level 8</option>
                                        <option value="9">Level 9</option>
                                        <option value="10">Level 10</option>
                                   </select>
                               </div>
                           </div>


                           <!-- final buttons -->
                        <div class="col-md-12">
                               <button type="submit" name="addNewAQFLevel" class="add__btn">
                                    <i class="fa fa-save"></i> Add AQF Level
                               </button>

                               <button type="Reset" class="add__btn">
                                    <i class="fa fa-window-restore"></i> Reset
                               </button>
                        </div>

                       </div>
                 </form>
             </div>
         </div>
     </div>
</div>

  <!-- include js -->
  <?php include("../includes/externalJs.php");?>
<script>
function goBack() {
  window.history.back();
}

 </script>
</body>

<?php 
   if(isset($_POST["addNewAQFLevel"])){
    $QUALIFIED_DEGREE=$_POST["QUALIFIED_DEGREE"];
    $AQF_LEVEL=$_POST["AQF_LEVEL"];
    $QUALIFICATION_LEVEL_REQUIRED_TO_TEACH=$_POST["QUALIFICATION_LEVEL_REQUIRED_TO_TEACH"];
    

    
   include("../../backend/AqfLevels.php");
   include("../../backend/db.php");
   $aqf = new AqfLevels($conn);
   $aqfInsertResult = $aqf->insertAqfLevel($QUALIFIED_DEGREE,$AQF_LEVEL,$QUALIFICATION_LEVEL_REQUIRED_TO_TEACH);
   if($aqfInsertResult === -1){    
    ?>
    <script>
           $(".error__message").text("Oops! AQF Level Already Exist.");
           $('#errorModal').modal('show'); 
    </script>
    <?php 
   }else if($aqfInsertResult){    
    ?>
    <script>
        $(".success__message").text("New AQF Level Added Successfully!");
        $('#successModal').modal('show');
    </script>
    <?php
   }else{
    //    show eerror
   ?>
     <script>
         $(".error__message").text("Oops! Something Went Wrong.");
         $('#errorModal').modal('show');
     </script>
   <?php
   } 
    

    ?>
    <script>history.pushState({}, "", "")</script>
    <?php
   }
   
?>
</html>

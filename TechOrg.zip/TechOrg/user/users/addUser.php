<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add User - TechOrg</title>
      <!-- include css -->
      <?php include("../includes/externalCss.php") ?>
</head>
<body>
    
<!-- include sidebar -->
<?php
  include("../includes/checkSession.php");
  include("../includes/sidebar.php");
  include("../../backend/db.php");
  include("../../backend/AqfLevels.php");
  $aqfLevel = new AqfLevels($conn);
?>

<div id="main">
    <div class="row">
        <div class="col-md-4">
            <button class="open__btn" id="openBtn" onclick="openNav()">☰ Menu</button>     
            <h2 class="text__primary__color page__heading" id="pageHeadingOpenSidebar"> <i class="fa fa-plus"></i> Add New User</h2>
        </div>
        <div class="col-md-6">
           <h2 class="text__primary__color page__heading" id="pageHeadingCloseSidebar"><i class="fa fa-plus"></i> Add New User</h2>
        </div>
        <div class="col-md-2">
              <a href="#" onclick="goBack()" class="add__btn"> <i class="fa fa-angle-left"></i> Back</a>
        </div>
    </div>
      <hr/>
     <div class="page__content">
         <div class="card">
             <div class="card-body">
                 <form action="" method="post">
                       <div class="row">
                           <div class="col-md-4">
                               <div class="form-group">
                                   <label for="USER_FIRST_NAME">User First Name*</label>
                                   <input type="text" name="USER_FIRST_NAME" id="USER_FIRST_NAME" class="form-control" placeholder="First Name" required/>
                               </div>
                           </div>


                           <div class="col-md-4">
                               <div class="form-group">
                                   <label for="USER_LAST_NAME">User Last Name*</label>
                                   <input type="text" name="USER_LAST_NAME" id="USER_LAST_NAME" class="form-control" placeholder="Last Name" required/>
                               </div>
                           </div>


                           <div class="col-md-4">
                               <div class="form-group">
                                   <label for="USER_EMAIL">User Email*</label>
                                   <input type="email" name="USER_EMAIL" id="USER_EMAIL" class="form-control" placeholder="Email" required/>
                               </div>
                           </div>

                           <div class="col-md-4">
                               <div class="form-group">
                                   <label for="USER_PASSWORD">User Password*</label>
                                   <input type="password" name="USER_PASSWORD" id="USER_PASSWORD" class="form-control" placeholder="Password" required/>
                               </div>
                           </div>

                           <div class="col-md-4">
                               <div class="form-group">
                                   <label for="USER_ROLE">User Role*</label>
                                   <select name="USER_ROLE" id="USER_ROLE" class="form-control" required>
                                        <option value="">Select User Role</option>
                                        <option value="0">User</option>
                                        <option value="1">Admin</option>
                                    </select>
                               </div>
                           </div>

                           <!-- final buttons -->
                        <div class="col-md-12">
                               <button type="submit" name="addNewUser" class="add__btn">
                                    <i class="fa fa-save"></i> Add User
                               </button>

                               <button type="Reset" class="add__btn">
                                    <i class="fa fa-window-restore"></i> Reset
                               </button>
                        </div>

                       </div>
                 </form>
             </div>
         </div>
     </div>
</div>

  <!-- include js -->
  <?php include("../includes/externalJs.php");?>
<script>
function goBack() {
  window.history.back();
}

 </script>
</body>

<?php 
   if(isset($_POST["addNewUser"])){
    $USER_FIRST_NAME=$_POST["USER_FIRST_NAME"];
    $USER_LAST_NAME=$_POST["USER_LAST_NAME"];
    $USER_EMAIL=$_POST["USER_EMAIL"];
    $USER_PASSWORD=$_POST["USER_PASSWORD"];
    $USER_ROLE=$_POST["USER_ROLE"];
    include("../../backend/helper/ValidationHelper.php");
    
    if(ValidationHelper::validatePassword($USER_PASSWORD)){
        include("../../backend/User.php");
        include("../../backend/db.php");
        $user = new User($conn);
        $userInsertResult = $user->insertNewUser($USER_FIRST_NAME,$USER_LAST_NAME,$USER_EMAIL,$USER_PASSWORD,$USER_ROLE);
        if($userInsertResult === -1){
            ?>
            <script>
                $(".error__message").text("Oops! User already exist");
                $('#errorModal').modal('show');
            </script>
          <?php 
           }else if($userInsertResult){    
            ?>
            <script>
                $(".success__message").text("New User Added Successfully!");
                $('#successModal').modal('show');
            </script>
            <?php
           }else{
            //    show eerror
           ?>
             <script>
                 $(".error__message").text("Oops! Something Went Wrong.");
                 $('#errorModal').modal('show');
             </script>
           <?php
           } 
    }else{
     ?>
     <script>
         $(".error__message").text("Password must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters");
         $('#errorModal').modal('show');
     </script>
   <?php
    }
    ?>
    <script>history.pushState({}, "", "")</script>
    <?php
   }
   
?>
</html>

<?php
  include("../includes/checkSession.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Users - TechOrg</title>
      <!-- include css -->
      <?php 
        include("../includes/externalCss.php"); 
        include("../includes/dataTableCss.php"); 
        include("../../backend/db.php");
        include("../../backend/User.php");
        $user = new User($conn);
      ?>
      
</head>
<body>
    
<!-- include sidebar -->
<?php include("../includes/sidebar.php") ?>
<div id="main">
    <div class="row">
        <div class="col-md-2">
            <button class="open__btn" id="openBtn" onclick="openNav()">☰ Menu</button>     
            <h2 class="text__primary__color page__heading" id="pageHeadingOpenSidebar"> <i class="fa fa-user-circle"></i> Users</h2>
        </div>
        <div class="col-md-8">
           <h2 class="text__primary__color page__heading" id="pageHeadingCloseSidebar"><i class="fa fa-user-circle"></i> Users</h2>
        </div>
        <div class="col-md-2">
              <a href="http://localhost/techOrg/user/users/addUser.php" class="add__btn"> <i class="fa fa-plus"></i> Add New User</a>
        </div>
    </div>
      <hr/>
     <div class="page__content">
          <div id="myTableWrapper" class="table-responsive">
            <table class="table stripe display nowrap" id="myTable">
                <thead class="thead bg__primary__color">
                    <tr>
                        <th>Sr. No.</th>                        
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Create At</th>
                        <th>Update At</th>                        
                    </tr>
                </thead>
                
                <tbody>
                    <?php 
                       $userData = $user->getAllUsers();
                       $srNo= 1;
                       foreach($userData as $userInfo){
                            ?>
                            <tr>
                                <td class="font__weight"><?php echo $srNo; ?></td>
                                <td class="font__weight"><?php echo $userInfo["USER_FIRST_NAME"]; ?></td>
                                <td class="font__weight"><?php echo $userInfo["USER_LAST_NAME"]; ?></td>
                                <td class="font__weight"><?php echo $userInfo["USER_EMAIL"]; ?></td>
                                <td class="font__weight"><?php echo $userInfo["USER_ROLE"] == 0 ? 'User':'Admin'; ?></td>
                                <td class="font__weight"><?php echo $userInfo["USER_STATUS"]; ?></td>
                                <td class="font__weight"><?php echo $userInfo["USER_CREATE_AT"]; ?></td>
                                <td class="font__weight"><?php echo $userInfo["USER_UPDATE_AT"]; ?></td>
                            </tr>
                            <?php
                            $srNo++;
                       }
                    ?>
                </tbody>

            </table>
          </div>
     </div>
</div>
    <!-- include js -->
<?php 
   include("../includes/externalJs.php");
   include("../includes/dataTableJs.php");
?>
</body>
</html>
<?php
  include("./includes/checkSession.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <!-- include css -->
    <?php include("./includes/externalCss.php") ?>
</head>
<body>

<!-- include sidebar -->
<?php include("./includes/sidebar.php") ?>
<?php 
   include("../backend/db.php");
   include("../backend/User.php");
   include("../backend/Staff.php");
   include("../backend/Location.php");
   include("../backend/AqfLevels.php");
   include("../backend/Approvals.php");
   $user = new User($conn);
?>
<div id="main">
    <div class="row">
        <div class="col-md-2">
            <button class="open__btn" id="openBtn" onclick="openNav()">☰ Menu</button>     
            <h2 class="text__primary__color page__heading" id="pageHeadingOpenSidebar">Dashboard</h2>
        </div>
        <div class="col">
        <h2 class="text__primary__color page__heading" id="pageHeadingCloseSidebar">Dashboard</h2>
        </div>
    </div>
    <hr/>
 
     <div class="page__content">
          
        <div class="row dashboard-card-row"> <!--main row -->
            <!-- first card user info -->
        <div class="col-md-6 col-lg-4 col-xl-3 mt-2">
            <div class="dashboard-card">
                        <!-- icon -->
                    <div class="dashboard-card-icon">
                        <span class="fa fa-user-circle gray-text"></span>
                    </div><!-- icon -->

                    <div class="vr"></div>
                    <!-- text -row -->
                    <div class="dashboard-card-text-row row">
                        <div class="col-md-12 col-sm-12 col-lg-12 dashboard-card-heading gray-text">
                        <span class="font__weight"> Welcome</span>
                            <center>
                               <?php echo $user->getUserFirstName().' '.$user->getUserLastName(); ?>
                            </center>                                       
                        </div>
                        
                    </div>
                    <!-- text -row -->
            </div>                             
        </div>
        <!-- first card user info --> 

        
        <!-- 2nd card selected month info -->
        <div class="col-md-6 col-lg-4 col-xl-3 mt-2">
            <div class="dashboard-card">
                    <!-- icon -->
                <div class="dashboard-card-icon">
                    <span class="fa fa-calendar-alt gray-text"></span>
                </div><!-- icon -->

                <div class="vr"></div>
                <!-- text -row -->
                <div class="dashboard-card-text-row row">
                    <div class="col-md-12 col-sm-12 col-lg-12 dashboard-card-heading gray-text">
                       <span class="font__weight"> Today Date</span>
                        <center><div style="font-size:0.9rem"><?php echo date("d-M-Y") ?></div>    </center>                                       
                    </div>
                    
                </div>
                <!-- text -row -->
            </div>
        </div><!-- 2nd card selected month info end-->


        <!-- 3rd card time info -->
        <div class="col-md-6 col-lg-4 col-xl-3 mt-2">
                             <div class="dashboard-card">
                                        <!-- icon -->
                                    <div class="dashboard-card-icon">
                                        <span class="fa fa-clock gray-text"></span>
                                    </div><!-- icon -->

                                    <div class="vr"></div>
                                        <!-- text -row -->
                                        <div class="dashboard-card-text-row row">
                                            <div class="col-md-12 col-sm-12 col-lg-12 dashboard-card-heading gray-text">
                                            <span class="font__weight">Clock</span>
                                            
                                                <center><div style="font-size:0.9rem" id="clock"></div></center>                                       
                                        </div>
                                        
                                    </div>
                                    <!-- text -row -->
                             </div>
         </div><!-- 3rd card time info end-->


         <!-- 4th selected month info -->
         <div class="col-md-6 col-lg-4 col-xl-3 mt-2">
                             <div class="dashboard-card">
                                        <!-- icon -->
                                    <div class="dashboard-card-icon">
                                        <span class="fa fa-calendar-minus gray-text"></span>
                                    </div><!-- icon -->

                                    <div class="vr"></div>
                                    <!-- text -row -->
                                    <div class="dashboard-card-text-row row">
                                        <div class="col-md-12 col-sm-12 col-lg-12 dashboard-card-heading gray-text">
                                            <span class="font__weight">Current Month</span>                                          
                                            <center><div style="font-size:0.9rem"><?php echo date("F");?></div></center>                                       
                                        </div>
                                        
                                    </div>
                                    <!-- text -row -->
                             </div>
         </div><!--  4th selected month info end-->

          <!-- 5th total staff info -->
          <div class="col-md-6 col-lg-4 col-xl-3 mt-2">
                             <div class="dashboard-card">
                                        <!-- icon -->
                                    <div class="dashboard-card-icon">
                                        <span class="fa fa-calendar-minus gray-text"></span>
                                    </div><!-- icon -->

                                    <div class="vr"></div>
                                    <!-- text -row -->
                                    <div class="dashboard-card-text-row row">
                                        <div class="col-md-12 col-sm-12 col-lg-12 dashboard-card-heading gray-text">
                                            <span class="font__weight">Total Staff Member</span>                                          
                                            <center><div style="font-size:0.9rem">
                                            <?php 
                                                 include("../backend/db.php");
                                                 $staff = new Staff($conn);
                                                echo $staff->getAllStaffCount();
                                            ?>
                                            </div></center>                                       
                                        </div>
                                        
                                    </div>
                                    <!-- text -row -->
                             </div>
         </div><!--  5th total staff info-->

         <!-- 6th total active user info -->
         <div class="col-md-6 col-lg-4 col-xl-3 mt-2">
                             <div class="dashboard-card">
                                        <!-- icon -->
                                    <div class="dashboard-card-icon">
                                        <span class="fa fa-users gray-text"></span>
                                    </div><!-- icon -->

                                    <div class="vr"></div>
                                    <!-- text -row -->
                                    <div class="dashboard-card-text-row row">
                                        <div class="col-md-12 col-sm-12 col-lg-12 dashboard-card-heading gray-text">
                                            <span class="font__weight">Total Users</span>                                          
                                            <center><?php echo $user->getAllUserCount();?></center>                                       
                                        </div>
                                        
                                    </div>
                                    <!-- text -row -->
                             </div>
         </div><!--  5th total staff info-->

          <!-- 7th card -->
          <div class="col-md-6 col-lg-4 col-xl-3 mt-2">
                             <div class="dashboard-card">
                                        <!-- icon -->
                                    <div class="dashboard-card-icon">
                                        <span class="fa fa-building gray-text"></span>
                                    </div><!-- icon -->

                                    <div class="vr"></div>
                                    <!-- text -row -->
                                    <div class="dashboard-card-text-row row">
                                        <div class="col-md-12 col-sm-12 col-lg-12 dashboard-card-heading gray-text">
                                            <span class="font__weight">Total Locations</span>                                          
                                            <center>
                                            <?php
                                                  include("../backend/db.php");
                                                  $location = new Location($conn);
                                                echo $location->getAllLocationCount();
                                             ?>
                                             </center>                                       
                                        </div>
                                        
                                    </div>
                                    <!-- text -row -->
                             </div>
         </div><!--  7th card-->


          <!-- 8th card -->
          <div class="col-md-6 col-lg-4 col-xl-3 mt-2">
                             <div class="dashboard-card">
                                        <!-- icon -->
                                    <div class="dashboard-card-icon">
                                        <span class="fa fa-list-alt gray-text"></span>
                                    </div><!-- icon -->

                                    <div class="vr"></div>
                                    <!-- text -row -->
                                    <div class="dashboard-card-text-row row">
                                        <div class="col-md-12 col-sm-12 col-lg-12 dashboard-card-heading gray-text">
                                            <span class="font__weight">Total Aqf Levels</span>                                          
                                            <center>
                                            <?php
                                                  include("../backend/db.php");
                                                  $aqf = new AqfLevels($conn);
                                                echo $aqf->getAllLAqfLevelCount();
                                             ?>
                                             </center>                                       
                                        </div>
                                        
                                    </div>
                                    <!-- text -row -->
                             </div>
         </div><!--  8th card-->

          <!-- 9th card -->
          <div class="col-md-6 col-lg-4 col-xl-3 mt-2">
                             <div class="dashboard-card">
                                        <!-- icon -->
                                    <div class="dashboard-card-icon">
                                        <span class="fa fa-check-circle gray-text"></span>
                                    </div><!-- icon -->

                                    <div class="vr"></div>
                                    <!-- text -row -->
                                    <div class="dashboard-card-text-row row">
                                        <div class="col-md-12 col-sm-12 col-lg-12 dashboard-card-heading gray-text">
                                            <span class="font__weight">New Approval Request</span>                                          
                                            <center>
                                            <?php
                                                  include("../backend/db.php");
                                                  $approvals = new Approvals($conn);
                                                echo $approvals->getAllNewApprovalRequest();
                                             ?>
                                             </center>                                       
                                        </div>
                                        
                                    </div>
                                    <!-- text -row -->
                             </div>
         </div><!--  9th card-->

     </div>
</div>
    <!-- include js -->
<?php include("./includes/externalJs.php") ?>
<script>
    // clock script
    const clock = ()=>{
        let date = new Date();
       $("#clock").html(`${date.toLocaleTimeString()}`)
    }
    setInterval(clock, 1000);
</script>
</body>
</html>
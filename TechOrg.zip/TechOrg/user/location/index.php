<?php
  include("../includes/checkSession.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Location - TechOrg</title>
      <!-- include css -->
      <?php 
        include("../includes/externalCss.php"); 
        include("../includes/dataTableCss.php"); 
        include("../../backend/db.php");
        include("../../backend/Location.php");
        $location = new Location($conn);
      ?>
      
</head>
<body>
    
<!-- include sidebar -->
<?php include("../includes/sidebar.php") ?>
<div id="main">
    <div class="row">
        <div class="col-md-2">
            <button class="open__btn" id="openBtn" onclick="openNav()">☰ Menu</button>     
            <h2 class="text__primary__color page__heading" id="pageHeadingOpenSidebar"> <i class="fa fa-building"></i> Location</h2>
        </div>
        <div class="col-md-8">
           <h2 class="text__primary__color page__heading" id="pageHeadingCloseSidebar"><i class="fa fa-building"></i> Location</h2>
        </div>
        <div class="col-md-2">
              <a href="http://localhost/techOrg/user/location/addLocation.php" class="add__btn"> <i class="fa fa-plus"></i> Add Location</a>
        </div>
    </div>
      <hr/>
     <div class="page__content">
          <div id="myTableWrapper" class="table-responsive">
            <table class="table stripe display nowrap" id="myTable">
                <thead class="thead bg__primary__color">
                    <tr>
                        <th>Sr. No.</th>
                        <th>Building Name</th>
                        <th>Street Name</th>
                        <th>City</th>
                        <th>State</th>
                        <th>Zip Code</th>
                        <th>Country</th>
                    </tr>
                </thead>
                
                <tbody>
                    <?php 
                       $locationData = $location->getActiveLocation();
                       $srNo= 1;
                       foreach($locationData as $locationInfo){
                            ?>
                            <tr>
                                <td class="font__weight"><?php echo $srNo; ?></td>
                                <td class="font__weight"><?php echo $locationInfo["BUILDING_NAME"]; ?></td>
                                <td class="font__weight"><?php echo $locationInfo["STREET_NAME"]; ?></td>
                                <td class="font__weight"><?php echo $locationInfo["CITY"]; ?></td>
                                <td class="font__weight"><?php echo $locationInfo["STATE"]; ?></td>
                                <td class="font__weight"><?php echo $locationInfo["ZIP_CODE"]; ?></td>
                                <td class="font__weight"><?php echo $locationInfo["COUNTRY"]; ?></td>
                                
                            </tr>
                            <?php
                            $srNo++;
                       }
                    ?>
                </tbody>

            </table>
          </div>
     </div>
</div>
    <!-- include js -->
<?php 
   include("../includes/externalJs.php");
   include("../includes/dataTableJs.php");
?>
</body>
</html>
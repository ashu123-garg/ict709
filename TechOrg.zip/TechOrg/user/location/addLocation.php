<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Location - TechOrg</title>
      <!-- include css -->
      <?php include("../includes/externalCss.php") ?>
</head>
<body>
    
<!-- include sidebar -->
<?php
  include("../includes/checkSession.php");
  include("../includes/sidebar.php");
  include("../../backend/db.php");
  include("../../backend/AqfLevels.php");
  $aqfLevel = new AqfLevels($conn);
?>

<div id="main">
    <div class="row">
        <div class="col-md-4">
            <button class="open__btn" id="openBtn" onclick="openNav()">☰ Menu</button>     
            <h2 class="text__primary__color page__heading" id="pageHeadingOpenSidebar"> <i class="fa fa-plus"></i> Add New Location</h2>
        </div>
        <div class="col-md-6">
           <h2 class="text__primary__color page__heading" id="pageHeadingCloseSidebar"><i class="fa fa-plus"></i> Add New Location</h2>
        </div>
        <div class="col-md-2">
              <a href="#" onclick="goBack()" class="add__btn"> <i class="fa fa-angle-left"></i> Back</a>
        </div>
    </div>
      <hr/>
     <div class="page__content">
         <div class="card">
             <div class="card-body">
                 <form action="" method="post">
                       <div class="row">
                           <div class="col-md-4">
                               <div class="form-group">
                                   <label for="BUILDING_NAME">Building Name*</label>
                                   <input type="text" name="BUILDING_NAME" id="BUILDING_NAME" class="form-control" placeholder="Building Name" required/>
                               </div>
                           </div>


                           <div class="col-md-4">
                               <div class="form-group">
                                   <label for="STREET_NAME">Street Name*</label>
                                   <input type="text" name="STREET_NAME" id="STREET_NAME" class="form-control" placeholder="Street Name" required/>
                               </div>
                           </div>


                           <div class="col-md-4">
                               <div class="form-group">
                                   <label for="CITY">City*</label>
                                   <input type="text" name="CITY" id="CITY" class="form-control" placeholder="City" required/>
                               </div>
                           </div>



                           <div class="col-md-4">
                               <div class="form-group">
                                   <label for="STATE">State*</label>
                                   <input type="text" name="STATE" id="STATE" class="form-control" placeholder="State" required/>
                               </div>
                           </div>

                           <div class="col-md-4">
                               <div class="form-group">
                                   <label for="ZIP_CODE">Zip Code*</label>
                                   <input type="number" name="ZIP_CODE" id="ZIP_CODE" class="form-control" placeholder="Zip Code"  min="00501" minlength="4" required/>
                               </div>
                           </div>

                           <div class="col-md-4">
                               <div class="form-group">
                                   <label for="COUNTRY">Country*</label>
                                   <input type="text" name="COUNTRY" id="COUNTRY" class="form-control" placeholder="Country" required/>
                               </div>
                           </div>

                           <!-- final buttons -->
                        <div class="col-md-12">
                               <button type="submit" name="addNewLocation" class="add__btn">
                                    <i class="fa fa-save"></i> Add Location
                               </button>

                               <button type="Reset" class="add__btn">
                                    <i class="fa fa-window-restore"></i> Reset
                               </button>
                        </div>

                       </div>
                 </form>
             </div>
         </div>
     </div>
</div>

  <!-- include js -->
  <?php include("../includes/externalJs.php");?>
<script>
function goBack() {
  window.history.back();
}

 </script>
</body>

<?php 
   if(isset($_POST["addNewLocation"])){
    $BUILDING_NAME=$_POST["BUILDING_NAME"];
    $STREET_NAME=$_POST["STREET_NAME"];
    $CITY=$_POST["CITY"];
    $STATE=$_POST["STATE"];
    $ZIP_CODE=$_POST["ZIP_CODE"];
    $COUNTRY=$_POST["COUNTRY"];

    
   include("../../backend/Location.php");
   include("../../backend/db.php");
   $location = new Location($conn);
   $locationInsertResult = $location->insertNewLocation($BUILDING_NAME,$STREET_NAME,$CITY,$STATE,$ZIP_CODE,$COUNTRY);
   if($locationInsertResult){    
    ?>
    <script>
        $(".success__message").text("New Location Added Successfully!");
        $('#successModal').modal('show');
    </script>
    <?php
   }else{
    //    show eerror
   ?>
     <script>
         $(".error__message").text("Oops! Something Went Wrong.");
         $('#errorModal').modal('show');
     </script>
   <?php
   } 
    

    ?>
    <script>history.pushState({}, "", "")</script>
    <?php
   }
   
?>
</html>

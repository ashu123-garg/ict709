<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Staff - TechOrg</title>
      <!-- include css -->
      <?php include("../includes/externalCss.php") ?>
</head>
<body>
    
<!-- include sidebar -->
<?php
  include("../includes/checkSession.php");
  include("../includes/sidebar.php");
  include("../../backend/db.php");
  include("../../backend/AqfLevels.php");
  $aqfLevel = new AqfLevels($conn);
?>

<div id="main">
    <div class="row">
        <div class="col-md-4">
            <button class="open__btn" id="openBtn" onclick="openNav()">☰ Menu</button>     
            <h2 class="text__primary__color page__heading" id="pageHeadingOpenSidebar"> <i class="fa fa-plus"></i> Add Staff Member</h2>
        </div>
        <div class="col-md-6">
           <h2 class="text__primary__color page__heading" id="pageHeadingCloseSidebar"><i class="fa fa-plus"></i> Add Staff Member</h2>
        </div>
        <div class="col-md-2">
              <a href="#" onclick="goBack()" class="add__btn"> <i class="fa fa-angle-left"></i> Back</a>
        </div>
    </div>
      <hr/>
     <div class="page__content">
         <div class="card">
             <div class="card-body">
                 <form  id="addStaffForm" action="" method="post">
                     <div class="row" id="step__1">
                         <div class="col-md-12 mb-3">
                           <h3>Personal Info</h3>
                         </div>                      
                        <div class="col-md-4">
                            <div class="form-group">
                                  <label for="staffTitle">Title*</label>
                                   <select  name="staffTitle" id="staffTitle" class="form-control"   required>
                                       <option value="">Select Title</option>
                                       <option value="Mr">Mr</option>
                                       <option value="Miss">Miss</option>
                                       <option value="Ms">Ms</option>
                                   </select>                           
                            </div>                        
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                  <label for="fName">First Name*</label>
                                   <input type="text" name="fName" id="fName" class="form-control" placeholder="First Name" required>                           
                            </div>                        
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                   <label for="lName">Last Name*</label>
                                   <input type="text" name="lName" id="lName" class="form-control" placeholder="Last Name" required>                           
                            </div>                        
                        </div>


                        <div class="col-md-4">
                            <div class="form-group">
                                   <label for="email">Email*</label>
                                   <input type="email" name="email" id="email" class="form-control" placeholder="Email" required>                           
                            </div>                        
                        </div>


                        <div class="col-md-4">
                            <div class="form-group">
                                   <label for="phone">Phone*</label>
                                   <input type="tel" name="phone" id="phone" class="form-control" placeholder="Phone" required>                           
                            </div>                        
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                   <label for="address">Address*</label>
                                   <textarea name="address" id="address" class="form-control" placeholder="Address" required></textarea>                           
                            </div>                        
                        </div>

                        <div class="col-md-12">
                            <hr/>                
                        </div>
                        
                     </div><!-----step 1 ------------>

                    
                     <div class="row" id="step__2">
                         <div class="col-md-12 mb-3 form__heading__info">
                           <h3>Qalifications  Info</h3>
                           <div class="float-right">
                                  <button onclick="cloneQalifications()" type="button" class="btn btn-primary"><i class="fa fa-plus"></i></button>
                                  <button type="button" onclick="removeCloneQalifications()" class="btn btn-info"><i class="fa fa-minus"></i></button>
                            </div>
                         </div>                      
                        <div class="col-md-4">
                            <div class="form-group">
                                  <label for="aqfId">Select Qualification*</label>
                                   <select name="aqfId[]" id="aqfId" class="form-control" required>
                                       <option value="">Select Qualification</option>
                                       <?php
                                          $aqfLevels =$aqfLevel->getAllActiveAqfLevels();
                                          foreach($aqfLevels as $aqfLevel){
                                              ?>
                                              <option value="<?php echo $aqfLevel["AQF_LEVEL_ID"];?>"><?php echo $aqfLevel["QUALIFIED_DEGREE"];?></option>
                                              <?php 
                                          }
                                       ?>
                                   </select>                               
                            </div>                         
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                  <label for="majorArea">Subject/major area*</label>
                                   <input type="text" name="majorArea[]" id="majorArea" class="form-control" placeholder="Major Area e.g. Computer Science" required>                           
                            </div>                        
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                   <label for="institutionName">Institution Name*</label>
                                   <input type="text" name="institutionName[]" id="institutionName" class="form-control" placeholder="Institution Name" required>                           
                            </div>                        
                        </div>


                        <div class="col-md-4">
                            <div class="form-group">
                                   <label for="country">Country*</label>
                                   <input type="text" name="country[]" id="country" class="form-control" placeholder="Country" required>                           
                            </div>                        
                        </div>


                        <div class="col-md-4">
                            <div class="form-group">
                                   <label for="awardFullName">Full Name of Award*</label>
                                   <input type="text" name="awardFullName[]" id="awardFullName" class="form-control" placeholder="Award Full Name eg. Master of Computer Science" required>                           
                            </div>                        
                        </div>

                        <div class="col-md-4">
                            <div class="form-group">
                                   <label for="awardedYear">Awarded Year*</label>
                                   <input type="month" name="awardedYear[]" id="awardedYear" class="form-control" placeholder="Awarded Year eg. June,2020" required>                           
                            </div>                        
                        </div>

                        <div class="col-md-12">
                             <hr/>                   
                        </div>

                        <div class="col-md-12 cloneQalifications">
                    
                        </div>
                        
                     </div><!-----step 2 ------------>
                      

                     <div class="row" id="step__3">

                         <div class="col-md-12 mb-3 form__heading__info">
                           <h3>Teaching Experience</h3> 

                            <div class="radio__btn"> 
                                 <div class="form-group">
                                      <label for="haveTeachingExperience">Do you have teaching experience?</label>
                                     &nbsp;
                                     <input type="radio" value="Yes" name="haveTeachingExperience" id="haveTeachingExperienceYes" required onclick="showTeachingExperienceSection()"> <strong>Yes</strong>
                                     &nbsp;
                                     <input type="radio" value="No" checked name="haveTeachingExperience" id="haveTeachingExperienceNo" required onclick="hideTeachingExperienceSection()"> <strong>No</strong>
                                 </div>
                            </div> 

                            <div class="float-right teachingExperienceSection">
                                  <button onclick="cloneTeachingExperience()" type="button" class="btn btn-primary"><i class="fa fa-plus"></i></button>
                                  <button type="button" onclick="removeClonedTeachingExperience()" class="btn btn-info"><i class="fa fa-minus"></i></button>
                            </div>
                         </div>                      
                        <div class="col-md-4 teachingExperienceSection">
                            <div class="form-group">
                                  <label for="joiningDate">Joining Date*</label>
                                   <input type="date" name="joiningDate[]" id="joiningDate" class="form-control" placeholder="Joining Date" required>                           
                            </div>                         
                        </div>

                        <div class="col-md-4 teachingExperienceSection">
                            <div class="form-group">
                                  <label for="majorArea">Finish Date*</label>
                                   <input type="date" name="finishDate[]" id="finishDate" class="form-control" placeholder="End Date" required>                           
                            </div>                        
                        </div>

                        <div class="col-md-4 teachingExperienceSection">
                            <div class="form-group">
                                   <label for="experienceInstitutionName">Organisation/Institution Name*</label>
                                   <input type="text" name="experienceInstitutionName[]" id="experienceInstitutionName" class="form-control" placeholder="Institution Name" required>                           
                            </div>                        
                        </div>


                        <div class="col-md-4 teachingExperienceSection">
                            <div class="form-group">
                                   <label for="experienceInstitutionCountry">Organisation/Institution Country*</label>
                                   <input type="text" name="experienceInstitutionCountry[]" id="experienceInstitutionCountry" class="form-control" placeholder="Organisation/Institution Country" required>                           
                            </div>                        
                        </div>


                        <div class="col-md-4 teachingExperienceSection">
                            <div class="form-group">
                                   <label for="experienceInstitutionRole">Role*</label>
                                   <select  name="experienceInstitutionRole[]" id="experienceInstitutionRole" class="form-control"  required>            
                                      <option value="">Your role in this organisation</option>
                                      <option>Assistant </option>
                                      <option>Course Coordinator</option>
                                      <option>Facilitator </option>
                                      <option>Instructor</option>
                                      <option>Lecturer</option>
                                      <option>Marker </option>
                                      <option>Tutor</option>
                                      <option>Teaching </option>
                                   </select>               
                            </div>                        
                        </div>

                       
                         
                        <div class="col-md-12">
                             <hr/>                
                        </div>

                        <div class="col-md-12 clonedTeachingExperience teachingExperienceSection">
                    
                       </div>
                        
                     </div><!-----step 3 ------------>

                     <div class="row" id="step__4">
                         <div class="col-md-12 mb-3 form__heading__info">
                           <h3>Relevant Employment/Experience </h3>
                           <div class="radio__btn"> 
                                 <div class="form-group">
                                      <label for="haveRelevantEmploymentExperience">Do you have relevant employment experience?</label>
                                     &nbsp;
                                     <input type="radio" value="Yes" name="haveRelevantEmploymentExperience" id="haveRelevantEmploymentExperienceYes" required onclick="showRelevantEmploymentExperienceSection()"> <strong>Yes</strong>
                                     &nbsp;
                                     <input type="radio" value="No" checked name="haveRelevantEmploymentExperience" id="haveRelevantEmploymentExperienceNo" required onclick="hideRelevantEmploymentExperienceSection()"> <strong>No</strong>
                                 </div>
                            </div> 
                           <div class="float-right relevantEmploymentExperienceSection">
                                  <button onclick="cloneRelevantEmploymentExperience()" type="button" class="btn btn-primary"><i class="fa fa-plus"></i></button>
                                  <button type="button" onclick="removeCloneRelevantEmploymentExperience()" class="btn btn-info"><i class="fa fa-minus"></i></button>
                            </div>
                         </div>
                         <div class="col-md-12 mb-3 form__heading__info relevantEmploymentExperienceSection">
                           <p><mark>Note: provide a brief history of the employment and/or other experience (if different to 2 & 4 above) which is relevant to the current higher education role and field of education.</mark> </p>
                         </div>                      
                        <div class="col-md-4 relevantEmploymentExperienceSection">
                            <div class="form-group">
                                  <label for="relevantJoiningDate">Joining Date*</label>
                                   <input type="date" name="relevantJoiningDate[]" id="relevantJoiningDate" class="form-control relevent__experience" placeholder="Joining Date" required>                           
                            </div>                         
                        </div>

                        <div class="col-md-4 relevantEmploymentExperienceSection">
                            <div class="form-group">
                                  <label for="relevantEndDate">Finish Date*</label>
                                   <input type="date" name="relevantEndDate[]" id="relevantEndDate" class="form-control relevent__experience" placeholder="End Date" required>                           
                            </div>                        
                        </div>

                        <div class="col-md-4 relevantEmploymentExperienceSection">
                            <div class="form-group">
                                   <label for="relevantEmploymentType">Employment Type*</label>
                                   <select name="relevantEmploymentType[]" id="relevantEmploymentType" class="form-control relevent__experience" required>    
                                        <option value="">Select Employement Type</option>
                                        <option>Full-Time</option>
                                        <option>Part-Time</option>
                                        <option>Casual</option>
                                   </select>                       
                            </div>                        
                        </div>


                        <div class="col-md-4 relevantEmploymentExperienceSection">
                            <div class="form-group">
                                   <label for="relevantEmployerName">Name of Employer*</label>
                                   <input type="text" name="relevantEmployerName[]" id="relevantEmployerName" class="form-control relevent__experience" placeholder="Employer Name" required>                           
                            </div>                        
                        </div>


                        <div class="col-md-4 relevantEmploymentExperienceSection">
                            <div class="form-group">
                                   <label for="relevantPositionTitle">Position Title*</label>
                                   <input type="text"  name="relevantPositionTitle[]" id="relevantPositionTitle" placeholder="Position Title" class="form-control relevent__experience"  required>            
                            </div>                        
                        </div>

                        <div class="col-md-4 relevantEmploymentExperienceSection">
                            <div class="form-group">
                                   <label for="relevantDuties">Relevant Duties*</label>
                                   <textarea type="text"  name="relevantDuties[]" id="relevantDuties" class="form-control relevent__experience" placeholder="Relevant Duties"  required></textarea>         
                            </div>                        
                        </div>

                       

                        <div class="col-md-12">
                             <hr/>      
                        </div>

                        <div class="col-md-12 cloneRelevantEmploymentExperience relevantEmploymentExperienceSection">
                    
                        </div>
                        
                     </div><!-----step 4 ------------>

                     <div class="row" id="step__5">
                         <div class="col-md-12 mb-3">
                           <h3>Other Relevant Information</h3>
                         </div>
                         <div class="col-md-12 mb-3">
                           <p><mark>Note: (including professional and/or honorary memberships, directorships and related scholarly activities) </mark> </p>
                         </div>                      
                        <div class="col-md-4">
                            <div class="form-group">
                                  <label for="otherRelevantInformation">Other Information</label>
                                   <textarea name="otherRelevantInformation" id="otherRelevantInformation" style="height:100px !important" class="form-control" placeholder="Other Relevent Information e.g.Member of Australian Computer Society, Local school board member"></textarea>                           
                            </div>                         
                        </div>                       

                        <div class="col-md-12">
                            <hr/>                    
                        </div>

                     </div><!-----step 5 ------------>

                     <div class="row" id="step__6">
                         <div class="col-md-12 mb-3 form__heading__info">
                           <h3>Publications(Scholarship And Research Outputs)</h3>
                           <div class="radio__btn"> 
                                 <div class="form-group">
                                      <label for="haveRelevantEmploymentExperience">Do you have publications(Scholarship And Research Outputs)?</label>
                                     &nbsp;
                                     <input type="radio" value="Yes" name="havePublication" id="havePublicationYes" required onclick="showPublicationSection()"> <strong>Yes</strong>
                                     &nbsp;
                                     <input type="radio" value="No" checked name="havePublication" id="havePublicationNo" required onclick="hidePublicationSection()"> <strong>No</strong>
                                 </div>
                            </div> 
                           <div class="float-right publicationSection">
                                  <button onclick="clonePubliction()" type="button" class="btn btn-primary"><i class="fa fa-plus"></i></button>
                                  <button type="button" onclick="removeClonePubliction()" class="btn btn-info"><i class="fa fa-minus"></i></button>
                            </div>
                         </div>                                           
                        <div class="col-md-4 publicationSection">
                            <div class="form-group">
                                  <label for="authorSurname">Author Surname*</label>
                                   <input type="text" name="authorSurname[]" id="authorSurname" class="form-control" placeholder="Author Surname" required>                          
                            </div>                         
                        </div> 
                        
                        
                        <div class="col-md-4 publicationSection">
                            <div class="form-group">
                                  <label for="authorInitial">Author Initial*</label>
                                   <input type="text" name="authorInitial[]" id="authorInitial" class="form-control" placeholder="Author Initial" required>                          
                            </div>                         
                        </div> 

                        <div class="col-md-4 publicationSection">
                            <div class="form-group">
                                  <label for="publicationYear">Year of Publication*</label>
                                   <select name="publicationYear[]" id="publicationYear" class="form-control" required>
                                        <option>Select Year of Publication</option>
                                        <?php
                                            $currentYear = date("Y");
                                           for($startYear = 1947; $startYear<=$currentYear;$startYear++){
                                               echo "<option>$startYear</option>";
                                           }
                                        ?>
                                   </select>                          
                            </div>                         
                        </div> 


                        <div class="col-md-4 publicationSection">
                            <div class="form-group">
                                  <label for="publicationTitle">Title of Publication*</label>
                                   <input type="text" name="publicationTitle[]" id="publicationTitle" class="form-control" placeholder="Publication Title" required>                          
                            </div>                         
                        </div> 

                        <div class="col-md-4 publicationSection">
                            <div class="form-group">
                                  <label for="journal_volume_proceedings">Journal/Volume/Proceedings*</label>
                                   <input type="text" name="journal_volume_proceedings[]" id="journal_volume_proceedings" class="form-control" placeholder="Journal/Volume/Proceedings" required>                          
                            </div>                         
                        </div>
                        
                        
                        <div class="col-md-4 publicationSection">
                            <div class="form-group">
                                  <label for="publicationType">Publication Type*</label>
                                   <select name="publicationType[]" id="publicationType" class="form-control" required>
                                          <option>Select Publication Type</option>
                                          <option>Journal</option>
                                          <option>Conference Proceedings</option>
                                          <option>Books</option>
                                          <option>Book Chapters</option>
                                   </select>                          
                            </div>                         
                        </div> 


                        <div class="col-md-4 publicationSection">
                            <div class="form-group">
                                  <label for="publicationReviewed">Peer-Refereed/Reviewed*</label>
                                   <select name="publicationReviewed[]" id="publicationReviewed" class="form-control" required>
                                          <option>Select Value</option>
                                          <option>Yes</option>
                                          <option>No</option>
                                   </select>                          
                            </div>                         
                        </div>
                        
                        
                        <div class="col-md-4 publicationSection">
                            <div class="form-group">
                                  <label for="researchClassification">Research Classification*</label>
                                   <select name="researchClassification[]" id="researchClassification" class="form-control" required>
                                          <option>Select Research Classification</option>
                                          <option>Research</option>
                                          <option>Scholarship</option>
                                   </select>                          
                            </div>                         
                        </div>


                        <div class="col-md-4 publicationSection">
                            <div class="form-group">
                                  <label for="educationBroadField">Broad Field of Education*</label>
                                   <input type="text" name="educationBroadField[]" id="educationBroadField" class="form-control" placeholder="Broad Field of Education" required>                          
                            </div>                         
                        </div>


                        <div class="col-md-12">
                             <hr/>                  
                        </div>

                        <div class="col-md-12 clonePubliction publicationSection">
                    
                        </div>

                     </div><!-----step 6 ------------>

                     <!-- <div class="row" id="step__7">
                         <div class="col-md-12 mb-3">
                           <h3>Other Relevant Information</h3>
                         </div>
                         <div class="col-md-12 mb-3">
                           <p><mark>Note: (including professional and/or honorary memberships, directorships and related scholarly activities) </mark> </p>
                         </div>                      
                        <div class="col-md-4">
                            <div class="form-group">
                                  <label for="otherRelevantInformation">Other Information</label>
                                   <textarea name="otherRelevantInformation[]" id="otherRelevantInformation" style="height:100px !important" class="form-control" placeholder="Other Relevent Information e.g.Member of Australian Computer Society, Local school board member"></textarea>                           
                            </div>                         
                        </div>                       

                        <div class="col-md-12">
                            <hr/>                    
                        </div>

                     </div>---step 7 ---------- -->

                     <div class="row" id="step__8">
                         <div class="col-md-12 mb-3 form__heading__info">
                           <h3>Documents</h3>
                           <div class="radio__btn">                                 
                            </div> 
                           <div class="float-right ">
                                  <button onclick="cloneDocument()" type="button" class="btn btn-primary"><i class="fa fa-plus"></i></button>
                                  <button type="button" onclick="removeCloneDocument()" class="btn btn-info"><i class="fa fa-minus"></i></button>
                            </div>
                         </div>                                           
                        <div class="col-md-4 ">
                            <div class="form-group">
                                  <label for="authorSurname">Document Name*</label>
                                   <input type="text" name="documentName[]" id="documentName" class="form-control" placeholder="Document Name" required>                          
                            </div>                         
                        </div>


                        <div class="col-md-12">
                             <hr/>                  
                        </div>

                        <div class="col-md-12 cloneDocument">
                    
                        </div>

                     </div><!-----step 8 ------------>
                    
                     <!-- final buttons -->
                     <div class="row">
                        <div class="col-md-12">
                               <button type="submit" name="addNewStaffMember" class="add__btn">
                                    <i class="fa fa-save"></i> Add Staff
                               </button>

                               <button type="Reset" class="add__btn">
                                    <i class="fa fa-window-restore"></i> Reset
                               </button>
                        </div>
                     </div>
                 </form>
             </div>
         </div>
     </div>
</div>

  <!-- include js -->
  <?php include("../includes/externalJs.php");?>
<script>
function goBack() {
  window.history.back();
}


function cloneQalifications(){
    let cloneDom= $("#step__2").clone();
    $(cloneDom).find(".form__heading__info").remove();
    $(cloneDom).find(".form-control").val("");
    $(cloneDom).find(".cloneQalifications").remove();
    $(cloneDom).find(".row").attr("id","");
    $("#step__2 .cloneQalifications").append(cloneDom);
}

function removeCloneQalifications(){
    $("#step__2 .cloneQalifications .row:last").remove();
}


function cloneTeachingExperience(){
    let cloneDom= $("#step__3").clone();
    $(cloneDom).find(".form__heading__info").remove();
    $(cloneDom).find(".form-control").val("");
    $(cloneDom).find(".clonedTeachingExperience").remove();
    $(cloneDom).find(".row").attr("id","");
    $("#step__3 .clonedTeachingExperience").append(cloneDom);
}

function removeClonedTeachingExperience(){
    $("#step__3 .clonedTeachingExperience .row:last").remove();
}

function cloneRelevantEmploymentExperience(){
    let cloneDom= $("#step__4").clone();
    $(cloneDom).find(".form__heading__info").remove();
    $(cloneDom).find(".form-control").val("");
    $(cloneDom).find(".cloneRelevantEmploymentExperience").remove();
    $(cloneDom).find(".row").attr("id","");
    $("#step__4 .cloneRelevantEmploymentExperience").append(cloneDom);
}

function removeCloneRelevantEmploymentExperience(){
    $("#step__4 .cloneRelevantEmploymentExperience .row:last").remove();
}

function clonePubliction(){
    let cloneDom= $("#step__6").clone();
    $(cloneDom).find(".form__heading__info").remove();
    $(cloneDom).find(".form-control").val("");
    $(cloneDom).find(".clonePubliction").remove();
    $(cloneDom).find(".row").attr("id","");
    $("#step__6 .clonePubliction").append(cloneDom);
}

function removeClonePubliction(){
    $("#step__6 .clonePubliction .row:last").remove();
}


function cloneDocument(){
    let cloneDom= $("#step__8").clone();
    $(cloneDom).find(".form__heading__info").remove();
    $(cloneDom).find(".form-control").val("");
    $(cloneDom).find(".cloneDocument").remove();
    $(cloneDom).find(".row").attr("id","");
    $("#step__8 .cloneDocument").append(cloneDom);
}

function removeCloneDocument(){
    $("#step__8 .cloneDocument .row:last").remove();
}

function showTeachingExperienceSection(){
    $(".teachingExperienceSection").show();
    $(".teachingExperienceSection").find('.form-control').prop("required",true);

}

function hideTeachingExperienceSection(){   
    $(".teachingExperienceSection").hide();
    $(".teachingExperienceSection").find('.form-control').prop("required",false);
}

function showRelevantEmploymentExperienceSection(){
    $(".relevantEmploymentExperienceSection").show();
    $(".relevantEmploymentExperienceSection").find('.form-control').prop("required",true);
}

function hideRelevantEmploymentExperienceSection(){   
    $(".relevantEmploymentExperienceSection").hide();
    $(".relevantEmploymentExperienceSection").find('.form-control').prop("required",false);
}

function showPublicationSection(){
    $(".publicationSection").show();
    $(".publicationSection").find('.form-control').prop("required",true);
}

function hidePublicationSection(){   
    $(".publicationSection").hide();
    $(".publicationSection").find('.form-control').prop("required",false);
}

hideTeachingExperienceSection();
hideRelevantEmploymentExperienceSection();
hidePublicationSection();
 </script>
</body>

<?php 
   if(isset($_POST["addNewStaffMember"])){
    //    1. Personal Info
     $staffTitle = $_POST["staffTitle"];
     $fName = $_POST["fName"];
     $lName = $_POST["lName"];
     $email = $_POST["email"];
     $phone = $_POST["phone"];
     $address = $_POST["address"];

    //    2. Qalifications  Info(multiple)
    $aqfId = $_POST["aqfId"];
    $majorArea = $_POST["majorArea"];
    $institutionName = $_POST["institutionName"];
    $country = $_POST["country"];
    $awardFullName = $_POST["awardFullName"];
    $awardedYear = $_POST["awardedYear"];    

    //    3.Teaching Experience(multiple)
   $haveTeachingExperience = $_POST["haveTeachingExperience"];
   $joiningDate = $_POST["joiningDate"];
   $finishDate = $_POST["finishDate"];
   $experienceInstitutionName = $_POST["experienceInstitutionName"];
   $experienceInstitutionCountry = $_POST["experienceInstitutionCountry"];
   $experienceInstitutionRole = $_POST["experienceInstitutionRole"];

   //    4.Relevant Employment/Experience(multiple)
   $haveRelevantEmploymentExperience = $_POST["haveRelevantEmploymentExperience"];
   $relevantJoiningDate = $_POST["relevantJoiningDate"];
   $relevantEndDate = $_POST["relevantEndDate"];
   $relevantEmploymentType = $_POST["relevantEmploymentType"];
   $relevantEmployerName = $_POST["relevantEmployerName"];
   $relevantPositionTitle = $_POST["relevantPositionTitle"];
   $relevantDuties = $_POST["relevantDuties"];

   //    5.Other Relevant Information
   $otherRelevantInformation = $_POST["otherRelevantInformation"];

   //    6.PUBLICATION
   $havePublication = $_POST["havePublication"];
   $authorSurname = $_POST["authorSurname"];
   $authorInitial = $_POST["authorInitial"];
   $publicationYear = $_POST["publicationYear"];
   $publicationTitle = $_POST["publicationTitle"];
   $journal_volume_proceedings = $_POST["journal_volume_proceedings"];
   $publicationType = $_POST["publicationType"];
   $publicationReviewed = $_POST["publicationReviewed"];
   $researchClassification = $_POST["researchClassification"];
   $educationBroadField = $_POST["educationBroadField"];

    //    8. documnets
   $documents = $_POST["documentName"];

   include("../../backend/Staff.php");
   include("../../backend/db.php");
   $staff = new Staff($conn);
   $staffInsertResult = $staff->insertNewStaffMember($staffTitle,$fName,$lName,$email,$phone,$address,$haveTeachingExperience,$haveRelevantEmploymentExperience,$havePublication);
   if($staffInsertResult === -1){
    //    staff already exist 
    // show  alert
    ?>
    <script>
           $(".error__message").text("Oops! Staff Member Already Exist.");
           $('#errorModal').modal('show'); 
    </script>
    <?php 
   }else if($staffInsertResult){
    //    insert qualification
    $staff->insertStaffQualification($staffInsertResult,$aqfId,$majorArea,$institutionName,$country,$awardFullName,$awardedYear);
    //insert teaching experience
    if($haveTeachingExperience ==="Yes"){
        $staff->insertTeachingExperience($staffInsertResult,$joiningDate,$finishDate,$experienceInstitutionName,$experienceInstitutionCountry,$experienceInstitutionRole);
    }
    
    //insert relevant  experience
    if($haveRelevantEmploymentExperience === "Yes"){
        $staff->insertRelevantEmploymentExperience($staffInsertResult,$relevantJoiningDate,$relevantEndDate,$relevantEmploymentType,$relevantEmployerName,$relevantPositionTitle,$relevantDuties);
    }

     //    insert other info
     $staff->insertOtherRelevantInfo($staffInsertResult,$otherRelevantInformation);

    //  insert docs
     $staff->insertDocuments($staffInsertResult,$documents);

    // insertPublication
    if($havePublication ==="Yes"){
       $staff->insertPublication($staffInsertResult,$authorSurname,$authorInitial,$publicationYear,$publicationTitle,$publicationType,$publicationReviewed,$researchClassification,$educationBroadField);
    }
    ?>
    <script>
        $(".success__message").text("Staff Member Added Successfully! Staff ID: <?php echo $staffInsertResult; ?>");
        $('#successModal').modal('show');
    </script>
    <?php
   }else{
    //    show eerror
   ?>
     <script>
         $(".error__message").text("Oops! Something Went Wrong.");
         $('#errorModal').modal('show');
     </script>
   <?php
   } 
    

    ?>
    <!-- <script>history.pushState({}, "", "")</script> -->
    <?php
   }
   
?>
</html>

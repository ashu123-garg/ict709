<?php
  include("../includes/checkSession.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Details - TechOrg</title>
      <!-- include css -->
      <?php 
        include("../includes/externalCss.php"); 
        include("../../backend/db.php");
        include("../../backend/Approvals.php");
        $approvals = new Approvals($conn);
      ?>
      
</head>
<body>
    
<!-- include sidebar -->
<?php include("../includes/sidebar.php") ?>
<div id="main">
    <div class="row">
        <div class="col-md-4">
            <button class="open__btn" id="openBtn" onclick="openNav()">☰ Menu</button>     
            <h2 class="text__primary__color page__heading" id="pageHeadingOpenSidebar"> <i class="fa fa-check-circle"></i> Staff Request Details <i class="fa fa-print" onclick="window.print()"></i> </h2>
        </div>
        <div class="col-md-6">
           <h2 class="text__primary__color page__heading" id="pageHeadingCloseSidebar"><i class="fa fa-check-circle"></i> Staff Request Details <i class="fa fa-print" onclick="window.print()"></i></h2>
        </div>
        <div class="col-md-2">
              <!-- <a href="http://localhost/techOrg/user/staff/insertStaff.php" class="add__btn"> <i class="fa fa-plus"></i> Add Staff</a> -->
        </div>
    </div>
      <hr/>
     <div class="page__content">
          <div id="" class="table-responsive">
               <h3>Personal Info</h3>
            <table class="table table-striped" id="">
                <thead class="thead bg__primary__color">
                    <tr>
                        <th>Sr. No.</th>
                        <th>Staff ID</th>
                        <th>Title</th>
                        <th>First Name</th>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Address</th>
                    </tr>
                </thead>
                
                <tbody>
                    <?php 
                       $reqId = $_GET["staffId"];
                       $approvalData = $approvals->getApprovalsDetailsByStaffId($reqId);
                       $srNo= 1;
                       foreach($approvalData as $approvalInfo){
                           if($srNo>1){
                           break;
                           }
                            ?>
                            
                            <tr>
                                <td class="font__weight"><?php echo $srNo; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["STAFF_ID"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["TITLE"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["FIRST_NAME"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["LAST_NAME"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["EMAIL"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["PHONE_NO"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["STAFF_ADDRESS"]; ?></td>
                            </tr>
                            <?php
                            $srNo++;
                       }
                    ?>
                </tbody>

            </table>
          </div>
          <hr/>

          <div id="" class="table-responsive">
               <h3>AQF Level Info</h3>
            <table class="table table-striped" id="">
                <thead class="thead bg__primary__color">
                    <tr>
                        <th>Sr. No.</th>
                        <th>Qualification</th>
                        <th>AQF Level</th>
                        <th>Required Qualification Level To Teach</th>
                    </tr>
                </thead>
                
                <tbody>
                    <?php 
                    //    $reqId = $_GET["req_id"];
                    //    $approvalData = $approvals->getApprovalsDetailsById($reqId);
                       $srNo= 1;
                       foreach($approvalData as $approvalInfo){
                            ?>
                            <tr>
                                <td class="font__weight"><?php echo $srNo; ?></td>                               
                                <td class="font__weight"><?php echo $approvalInfo["QUALIFIED_DEGREE"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["AQF_LEVEL"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["QUALIFICATION_LEVEL_REQUIRED_TO_TEACH"]; ?></td>
                            </tr>
                            <?php
                            $srNo++;
                       }
                    ?>
                </tbody>

            </table>
          </div>
          <hr/>


          <div id="" class="table-responsive">
               <h3>Approval Details</h3>
            <table class="table table-striped" id="">
                <thead class="thead bg__primary__color">
                    <tr>
                        <th>Sr. No.</th>
                        <th>STAFF ID</th>
                        <th>IS APPROVED</th>
                        <th>APPROVE DATE</th>
                        <th>NEXT REVIEW DATE</th>
                        <th>APPROVE BY</th>
                        <th>APPROVAL STATUS</th>
                        <th>NOTES</th>
                    </tr>
                </thead>
                
                <tbody>
                    <?php                    
                       $srNo= 1;
                       foreach($approvalData as $approvalInfo){
                            ?>
                            <tr>
                                <td class="font__weight"><?php echo $srNo; ?></td>                               
                                <td class="font__weight"><?php echo $approvalInfo["STAFF_ID"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["IS_APPROVED"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["APPROVE_DATE"] =="0000-00-00" ? "N/A": $approvalInfo["APPROVE_DATE"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["NEXT_REVIEW_DATE"] =="0000-00-00" ? "N/A": $approvalInfo["NEXT_REVIEW_DATE"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["APPROVE_BY"] == 0 ? 'N/A' :  $approvalInfo["APPROVE_BY"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["APPROVAL_STATUS"]; ?></td>
                                <td class="font__weight"><?php echo $approvalInfo["NOTES"] == '' ? 'N/A' : $approvalInfo["NOTES"]; ?></td>
                            </tr>
                            <?php
                            $srNo++;
                       }
                    ?>
                </tbody>

            </table>
          </div>
          <hr/>


          <div id="" class="table-responsive">
               <h3>Qualification Details</h3>
            <table class="table table-striped" id="">
                <thead class="thead bg__primary__color">
                    <tr>
                        <th>Qualification</th>
                        <th>Subject Area</th>
                        <th>Institution Name</th>
                        <th>Institution Country</th>
                        <th>Award Full Name</th>
                        <th>Award Year</th>
                        <th>AQF Level</th>
                        <th>Required Level</th>
                    </tr>
                </thead>
                
                <tbody>
                    <?php                    
                       $qualificationData = $approvals->getQualificationDetailsByStaffId($approvalInfo["STAFF_ID"]);
                       foreach($qualificationData as $qualificationInfo){
                            ?>
                            <tr>
                                <td class="font__weight"><?php echo $qualificationInfo["QUALIFIED_DEGREE"]; ?></td>
                                <td class="font__weight"><?php echo $qualificationInfo["SUBJECT_AREA"]; ?></td>
                                <td class="font__weight"><?php echo $qualificationInfo["INSTITUTION_NAME"]; ?></td>
                                <td class="font__weight"><?php echo $qualificationInfo["INSTITUTION_COUNTRY"]; ?></td>
                                <td class="font__weight"><?php echo $qualificationInfo["FULL_NAME_OF_AWARD"]; ?></td>
                                <td class="font__weight"><?php echo $qualificationInfo["AWARDED_YEAR"]; ?></td>
                                <td class="font__weight"><?php echo $qualificationInfo["AQF_LEVEL"]; ?></td>
                                <td class="font__weight"><?php echo $qualificationInfo["QUALIFICATION_LEVEL_REQUIRED_TO_TEACH"]; ?></td>
                            </tr>
                            <?php
                       }
                    ?>
                </tbody>

            </table>
          </div>
          <hr/>


          <div id="" class="table-responsive">
               <h3>Teaching Experience</h3>
            <table class="table table-striped" id="">
                <thead class="thead bg__primary__color">
                    <tr>
                        <th>Joining Date</th>
                        <th>Finish Date</th>
                        <th>Institution Name</th>
                        <th>Institution Country</th>
                        <th>Role</th>
                    </tr>
                </thead>
                
                <tbody>
                    <?php                    
                       $teachingData = $approvals->getTeachingExperienceByStaffId($approvalInfo["STAFF_ID"]);
                       foreach($teachingData as $teachingInfo){
                            ?>
                            <tr>
                                <td class="font__weight"><?php echo $teachingInfo["JOINING_DATE"]; ?></td>
                                <td class="font__weight"><?php echo $teachingInfo["FINISH_DATE"]; ?></td>
                                <td class="font__weight"><?php echo $teachingInfo["INSTITUTION_NAME"]; ?></td>
                                <td class="font__weight"><?php echo $teachingInfo["INSTITUTION_COUNTRY"]; ?></td>
                                <td class="font__weight"><?php echo $teachingInfo["ROLE"]; ?></td>                                
                            </tr>
                            <?php
                       }
                    ?>
                </tbody>

            </table>
          </div>
          <hr/>

          <div id="" class="table-responsive">
               <h3>Relevent Employement Experience</h3>
            <table class="table table-striped" id="">
                <thead class="thead bg__primary__color">
                    <tr>
                        <th>Joining Date</th>
                        <th>Finish Date</th>
                        <th>Employment Type</th>
                        <th>Employer Name</th>
                        <th>Position Title</th>
                        <th>Relevant Duties</th>
                    </tr>
                </thead>
                
                <tbody>
                    <?php                    
                       $relavantData = $approvals->getRelevantEmployementExperienceByStaffId($approvalInfo["STAFF_ID"]);
                       if(!count($relavantData)){
                        ?>
                          <tr><td class="font__weight text-center" colspan="6">Data Not Found!</td></tr>
                        <?php 
                        }
                       foreach($relavantData as $relavantInfo){
                            ?>
                            <tr>
                                <td class="font__weight"><?php echo $relavantInfo["JOINING_DATE"]; ?></td>
                                <td class="font__weight"><?php echo $relavantInfo["FINISH_DATE"]; ?></td>
                                <td class="font__weight"><?php echo $relavantInfo["EMPLOYMENT_TYPE"]; ?></td>
                                <td class="font__weight"><?php echo $relavantInfo["EMPLOYER_NAME"]; ?></td>
                                <td class="font__weight"><?php echo $relavantInfo["POSITION_TITLE"]; ?></td>                                
                                <td class="font__weight"><?php echo $relavantInfo["RELEVANT_DUTIES"]; ?></td>                                
                            </tr>
                            <?php
                       }
                    ?>
                </tbody>

            </table>
          </div>
          <hr/>

            <div id="" class="table-responsive">
               <h3>Publication Details</h3>
            <table class="table table-striped" id="">
                <thead class="thead bg__primary__color">
                    <tr>
                        <th>Author Surname</th>
                        <th>Initial</th>
                        <th>Publication Year</th>
                        <th>Title</th>
                        <th>Type</th>
                        <th>Reviewed</th>
                        <th>Classification</th>
                        <th>Broad Field</th>
                    </tr>
                </thead>
                
                <tbody>
                    <?php                    
                       $publicationData = $approvals->getPublicationDetailsByStaffId($approvalInfo["STAFF_ID"]);
                       if(!count($publicationData)){
                        ?>
                          <tr><td class="font__weight text-center" colspan="6">Data Not Found!</td></tr>
                        <?php 
                        }
                       foreach($publicationData as $publicationInfo){
                            ?>
                            <tr>
                                <td class="font__weight"><?php echo $publicationInfo["AUTHOR_SURNAME"]; ?></td>
                                <td class="font__weight"><?php echo $publicationInfo["AUTHOR_INITIAL"]; ?></td>
                                <td class="font__weight"><?php echo $publicationInfo["YEAR_OF_PUBLICATION"]; ?></td>
                                <td class="font__weight"><?php echo $publicationInfo["TITLE_OF_PUBLICATION"]; ?></td>
                                <td class="font__weight"><?php echo $publicationInfo["TYPE_OF_PUBLICATION"]; ?></td>                                
                                <td class="font__weight"><?php echo $publicationInfo["PEER_REVIEWED"]; ?></td>                                
                                <td class="font__weight"><?php echo $publicationInfo["CLASSIFICATION"]; ?></td>                                
                                <td class="font__weight"><?php echo $publicationInfo["BROAD_FIELD_EDUCATION"]; ?></td>                                
                            </tr>
                            <?php
                       }
                    ?>
                </tbody>

            </table>
          </div>
          <hr/>

          <div id="" class="table-responsive">
               <h3>Documents Details</h3>
            <table class="table table-striped" id="">
                <thead class="thead bg__primary__color">
                    <tr>
                        <th>Sr. No.</th>
                        <th>Document Name</th>
                        <th>Create By</th>
                        <th>Create Date</th>
                    </tr>
                </thead>
                
                <tbody>
                    <?php                    
                       $relavantData = $approvals->getDocumentDetailsByStaffId($approvalInfo["STAFF_ID"]);
                       $srNo=1;
                       if(!count($relavantData)){
                        ?>
                          <tr><td class="font__weight text-center" colspan="6">Data Not Found!</td></tr>
                        <?php 
                        }
                       foreach($relavantData as $relavantInfo){
                            ?>
                            <tr>
                                <td class="font__weight"><?php echo $srNo; ?></td>
                                <td class="font__weight"><?php echo $relavantInfo["DOCS_NAME"]; ?></td>
                                <td class="font__weight"><?php echo $relavantInfo["USER_FIRST_NAME"]; ?></td>
                                <td class="font__weight"><?php echo $relavantInfo["DOCUMENT_CREATE_AT"]; ?></td>                                                               
                            </tr>
                            <?php
                            $srNo++;
                       }
                    ?>
                </tbody>

            </table>
          </div>
          <hr/>

          <div id="" class="table-responsive">
               <h3>Other Relevant Info</h3>
            <table class="table table-striped" id="">
                <thead class="thead bg__primary__color">
                    <tr>
                        <th>Sr. No.</th>
                        <th>Relevant Info</th>
                    </tr>
                </thead>
                
                <tbody>
                    <?php                    
                       $relavantData = $approvals->getOtherRelevantInfoByStaffId($approvalInfo["STAFF_ID"]);
                       $srNo=1;
                       if(!count($relavantData)){
                        ?>
                          <tr><td class="font__weight text-center" colspan="6">Data Not Found!</td></tr>
                        <?php 
                        }
                       foreach($relavantData as $relavantInfo){
                            ?>
                            <tr>
                                <td class="font__weight"><?php echo $srNo; ?></td>
                                <td class="font__weight"><?php echo $relavantInfo["RELEVANT_INFO"]; ?></td>
                            </tr>
                            <?php
                            $srNo++;
                       }
                    ?>
                </tbody>

            </table>
          </div>
          <hr/>

        
     </div>
</div>
    <!-- include js -->
<?php 
   include("../includes/externalJs.php");
?>
</body>
</html>
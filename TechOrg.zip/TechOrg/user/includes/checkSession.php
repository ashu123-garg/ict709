<?php 
session_start();

if(
    !isset($_SESSION["user_auth_id"]) &&
    !isset($_SESSION["user_role"]) 
  ){
    //   Unauthorized user 
    // redirect to login page
    header("Location: ../index.php");
}
?>
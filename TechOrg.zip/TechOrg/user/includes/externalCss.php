<link rel="stylesheet" href="http://localhost/techOrg/css/style.css">
<link rel="stylesheet" href="http://localhost/techOrg/css/sidebar.css">
<link rel="stylesheet" href="http://localhost/techOrg/css/bootstrap.min.css">
<link rel="stylesheet" href="http://localhost/techOrg/assets/icons/fontawesome/css/all.min.css">
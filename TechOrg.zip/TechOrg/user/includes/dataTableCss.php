<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.6.2/css/buttons.dataTables.min.css">
<style>
/* datable customisation*/
#myTableWrapper input[type="search"] {
  border: none !important;
  padding: 10px 15px  !important;
  border-radius: 12px !important;
}

#myTableWrapper select {
  border: none !important;
  padding: 6px 15px !important;
  border-radius: 12px !important;
}
#myTableWrapper input:focus,
#myTableWrapper select:focus {
  transition: 0.3s ease-in !important;
  outline: none !important;
  box-shadow: 0 0px 2px #f1f1f1 !important;
}

.current {
  border: none !important;
  border-radius: 6px !important;
  cursor: pointer !important;
  background: #fff !important;
  padding: 6px 16px !important;
  border-radius: 20% !important;
}
.paginate_button {
  border: none !important;
  background: #fff !important;
}

.dt-button {
  border: none !important;
  background-color: blue !important;
  box-shadow: 0.3px 1px 1px #d0d0d0 !important;
  border-radius: 4px !important;
}

.paginate_button {
  transition: 0.2s ease-in-out !important;
  outline: none !important;
  box-shadow: 0 0px 2px #f1f1f1 !important;
  color:#282828 !important;
  cursor:pointer !important;
}

#myTable_previous:hover{
  opacity:0.7 !important;
  color:#282828 !important;

}
/* datable customisation*/


</style>
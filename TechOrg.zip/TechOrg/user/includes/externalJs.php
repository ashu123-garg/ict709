<script src="http://localhost/techOrg/js/jquery.js"></script>
<script src="http://localhost/techOrg/js/bootstrap.min.js"></script>
<script src="http://localhost/techOrg/js/popover.js"></script>
<script src="http://localhost/techOrg/js/sidebar.js"></script>
<script src="http://localhost/techOrg/assets/icons/fontawesome/js/all.min.js"></script>
<!-- open nav by default -->
<script>
    openNav();
</script>
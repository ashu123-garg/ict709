<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.6.2/js/dataTables.buttons.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.flash.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.html5.min.js"></script>
	<script type="text/javascript" language="javascript" src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.print.min.js"></script>
	<script>
		$(document).ready( function () {
        $('#myTable').DataTable({
            language: {
                  searchPlaceholder: "Search"                  
             },
             dom: 'Bfrtip',
            buttons: [                
                {
                    extend: 'copy',
                    footer: true,
                    exportOptions: {
                        columns: 'th:not(:last-child)'
                    }
                },            
                {
                    extend: 'print',
                    footer: true,
                    exportOptions: {
                        columns: 'th:not(:last-child)'
                    }
                },
                {
                    extend: 'csv',
                    footer: true,
                    exportOptions: {
                        columns: 'th:not(:last-child)'
                    }
                },
                {
                    extend: 'excel',
                    footer: true,
                    exportOptions: {
                        columns: 'th:not(:last-child)'
                    }
                },
                {
                    extend: 'pdf',
                    footer: true,
                    exportOptions: {
                        columns: 'th:not(:last-child)'
                    }
                },
                
            ],
           
        }); //dataTable
        $(".buttons-copy").html("<li class='fa fa-copy text__primary__color'></li> <span class='text__primary__color'>Copy</span>")
        $(".buttons-csv").html("<li class='fa fa-file text__primary__color'></li> <span class='text__primary__color'>CSV</span>")
        $(".buttons-excel").html("<li class='fa fa-file-excel text__primary__color'></li> <span class='text__primary__color'>Excel</span>")
        $(".buttons-pdf").html("<li class='fa fa-file-pdf text__primary__color'></li> <span class='text__primary__color'>PDF</span>")
        $(".buttons-print").html("<li class='fa fa-print text__primary__color'></li> <span class='text__primary__color'>Print</span>")
    });
	</script>
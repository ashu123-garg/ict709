<div id="mySidebar" class="sidebar">
  <a href="javascript:void(0)" class="close__btn" onclick="closeNav()">&times;</a>
  <a href="http://localhost/techOrg/user"><i class="fa fa-tachometer-alt"></i> Dashboard</a>
  <a href="http://localhost/techOrg/user/staff"> <i class="fa fa-users"></i> Staff</a>
  <a href="http://localhost/techOrg/user/aqf"> <i class="fa fa-list-alt"></i> AQF</a>
  <a href="http://localhost/techOrg/user/location"> <i class="fa fa-building"></i> Location</a>
  <?php
     if($_SESSION["user_role"]== 1){
          ?>
           <a href="http://localhost/techOrg/user/approval"> <i class="fa fa-check-circle"></i> Approval</a>
           <a href="http://localhost/techOrg/user/review"> <i class="fa fa-comments"></i> Review</a>
           <a href="http://localhost/techOrg/user/users"> <i class="fa fa-user-circle"></i> Users</a>
          <?php
     }
  ?>

 
  <a href="javascript:void(0)" data-toggle="modal" data-target="#logoutModal"><i class="fa fa-sign-out-alt"></i> Logout</a>
</div>



<!--Logout Modal -->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Alert</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        Are you sure you want to logout now?
      </div>
      <div class="modal-footer">
        <button type="button" class="add__btn" data-dismiss="modal"> <i class="fa fa-times"></i> Close</button>
        <a href="http://localhost/techOrg/user/logout" class="add__btn"> <i class="fa fa-check"></i> Sure</a>
      </div>
    </div>
  </div>
</div>



<!--success Modal -->
<div class="modal fade" id="successModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Alert</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <center> <i class="fa fa-check-circle display-4 text-large text__primary__color"></i></center>
        <center>
           <h6 class="success__message">Are you sure you want to logout now?</h6>
        </center>
      </div>
      <div class="modal-footer">
        <button type="button" class="add__btn" data-dismiss="modal"> <i class="fa fa-times"></i> Close</button>
      </div>
    </div>
  </div>
</div>

<!--error Modal -->
<div class="modal fade" id="errorModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Alert</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <center> <i class="fa fa-times-circle display-4 text-danger"></i></center>
        <center>
          <h6 class="error__message">
            Are you sure you want to logout now?
          </h6>  
      </center>      
      </div>
      <div class="modal-footer">
        <button type="button" class="add__btn" data-dismiss="modal"> <i class="fa fa-times"></i> Close</button>
      </div>
    </div>
  </div>
</div>